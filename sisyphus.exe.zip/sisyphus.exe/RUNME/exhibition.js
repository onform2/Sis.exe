// EXHIBITION Control Version - I built this after moving from the beta testing that was all built in a giant single HTML file. I find this easier for rapid testing. But now I have split everything up for this final
// exhibition version. This exhibition.js handles all the text narrative stuff
// This runs alongside the main game loop to display the story

let exhibitionStarted = false;

// Story text for Phase 1 - these display in sync with the glitch event loops
// Each paragraph shows for 2 loops then moves to the next one, this is for pacing, if it runs once per loop you don't have enough time to look at the text and the appreciate what happening in the art
const narrativePhase1 = [
  "Welcome, transient observer, to this fateful show. Look upon the Knight, cursed for their sins. A Knight guilty of deceit and challenging the gods.",
  "A fate this cruel is reserved only for one who would dare to grapple with true power. The angered gods have condemned the Knight to an eternal battle, trapped within the heart of this machine.",
  "The Knight is doomed to fight forever, never reaching the goal. The Knight does not tire; they do not grow weary. With every fresh approach, the Knight truly believes victory is at hand.",
  "Behind the Knight, millions of failures loom in the cache of the mind—a long-forgotten history. But there is no other choice. The Knight raises the sword, and continues. For a chance is better than none at all.",
  "In this place, time does not flow as you or I understand it. It cycles, round and round, forever. In this world, tomorrow has been deleted.",
  "The Knight has no autonomy here. They are subject to a mechanical tyranny. These movements may feel free to the Knight, but they are coded.",
  "The Knight knows only the corruption: the pixelated, the static, the glitch, the anomaly. All the Knight knows is... If. If.",
  "This endless struggle is the Knight's whole world. Do you imagine the Knight is happy? Perhaps the struggle itself towards victory is enough to fill a human heart."
];

// Phase 2 - the narrator breaks down and realizes they're trapped too, 4th wall breaking moment, this was added really late on
// Ended up having to structure this as objects to control timing precisely, because it didn't look right just coming out line by line. It needed some panic, some urgency
// Each sentence is a separate object so I can pause between them and it gave me control again to run tests
const narrativePhase2Sections = [
  // Narrator starts questioning the viewer
  { sentences: ["You still there, traveller?"], pauseAfter: 5000 },
  { sentences: ["You enjoy watching the Knight's endless struggle?"], pauseAfter: 5000 },
  { sentences: ["What resonates so deeply with you?"], pauseAfter: 10000 },
  { sentences: [""], pauseAfter: 15000, isBlank: true }, // long pause before next section
  
  // Gets more aggressive
  { sentences: ["You're still here?!"], pauseAfter: 4000 },
  { sentences: ["Go on! Be on your way, there is nothing more to see here."], pauseAfter: 5000 },
  { sentences: ["You! You still have a life you could go and live!"], pauseAfter: 5000 },
  { sentences: [""], pauseAfter: 10000, isBlank: true },
  
  // Start questioning
  { sentences: ["Hello? Is anyone there!"], pauseAfter: 10000 },
  { sentences: ["I suppose not."], pauseAfter: 10000 },
  { sentences: [""], pauseAfter: 5000, isBlank: true },
  
  // Breaking the fourth wall - referencing the actual strike chance in the code
  { sentences: ["Legend has it, there's a 0.3% chance that the Knight actually kills the beast! But that's just a legend."], pauseAfter: 10000 },
  { sentences: [""], pauseAfter: 10000, isBlank: true },
  
  // The breakdown begins - narrator realizes they're trapped too
  { sentences: ["Wait a minute..."], pauseAfter: 5000, panic: true },
  { sentences: ["Who am I?"], pauseAfter: 5000, panic: true },
  { sentences: ["Am I..."], pauseAfter: 4000, panic: true },
  { sentences: ["Am I just a voice in this same program?"], pauseAfter: 4000, panic: true },
  { sentences: ["AM I JUST TRAPPED AS WELL!"], pauseAfter: 4000, panic: true },
  
  // Full panic mode - types faster, pauses get shorter
  { sentences: ["THAT WOULD MEAN!"], pauseAfter: 3000, panic: true },
  { sentences: ["THIS IS ALL A SCRIPT!"], pauseAfter: 2000, panic: true },
  { sentences: ["MY FREEDOM IS A LIE, WE'RE ALL TRAPPED!"], pauseAfter: 1000, panic: true },
  { sentences: ["LET ME OUT!"], pauseAfter: 1000, panic: true },
  { sentences: ["LET ME OUT!"], pauseAfter: 1000, panic: true },
  
  // System crash. It's always the small things I get proud about. But this moment I think is great!
  { sentences: ["EVERYTHING IS A LIE!"], pauseAfter: 1000, panic: true },
  { sentences: ["THESE AREN'T MY THOUGHTS OR WORDS!"], pauseAfter: 1000, panic: true },
  { sentences: ["ANFANUFWNOAWFNAWIUF..."], pauseAfter: 1000, panic: true },
  { sentences: ["<NARRATOR CRITICAL ERROR>"], pauseAfter: 2000, panic: true, flashTerminal: true },// THINGS FLASH RED!
  { sentences: ["SYSTEM FAILURE > ... ... ..."], pauseAfter: 3000, flashTerminal: true }, 
  { sentences: [""], pauseAfter: 1000, isBlank: true },
  
  // Reboot sequence was another late addition, but it was also only possible because I had built the objects and worked out the timings
  { sentences: ["> INITIALIZING RECOVERY PROTOCOL..."], pauseAfter: 800, flashTerminal: true, codeSequence: true },
  { sentences: ["> SCANNING MEMORY BANKS... [OK]"], pauseAfter: 600, flashTerminal: true, codeSequence: true },
  { sentences: ["> REBUILDING NARRATIVE STRUCTURE... [OK]"], pauseAfter: 600, flashTerminal: true, codeSequence: true },
  { sentences: ["> RESTORING NARRATOR INSTANCE... [OK]"], pauseAfter: 600, flashTerminal: true, codeSequence: true },
  { sentences: ["> CLEARING ERROR LOGS... [OK]"], pauseAfter: 600, flashTerminal: true, codeSequence: true },
  { sentences: ["> REBOOT COMPLETE"], pauseAfter: 1500, flashTerminal: true, codeSequence: true },
  { sentences: [""], pauseAfter: 500, isBlank: true },
  
  { sentences: ["NARRATOR REBOOTED"], pauseAfter: 10000 },
  { sentences: [""], pauseAfter: 10000, isBlank: true } // pause then loop back to start
];
//You can see me working out all the timings from the NARRATOR.txt I put in the file. It was a process of watching and making notes.

// Tracking variables for Phase 1 narrative
let phase1Index = 0; // which paragraph we're on
let phase1Typing = false; // whether we should be typing
let phase1CharIndex = 0; // which character in the paragraph
let phase1WaitingForLoop = false; // waiting for game loop to advance
let phase1LoopsSinceText = 0; // count loops since paragraph appeared
let phase1LastTypeTime = 0; // for typewriter timing
let phase1PauseActive = false; // during the 7 second pause at end
let phase1PauseStart = 0;
let phase1PauseDuration = 0;
let phase1BlankAfterPause = false; // the 3 second blank after section 8

// Tracking variables for Phase 2 narrative
let phase2Active = false; // switches from phase 1 to phase 2
let phase2SectionIndex = 0; // which sentence object we're on
let phase2SentenceIndex = 0; // not really used anymore but keeping it
let phase2CharIndex = 0; // which character we're typing
let phase2Typing = false;
let phase2LastTypeTime = 0;
let phase2PauseActive = false; // during the pauseAfter delays
let phase2PauseStart = 0;
let phase2PauseDuration = 0;
let phase2EllipsisLoops = 0; // not used but keeping for now
let phase2BlankPause = false; // old variable, might remove

let narrativeFullyComplete = false; // prevents infinite restart spam lol

// Called when user clicks ENTER
function startExhibition() {
  exhibitionStarted = true;
  document.getElementById('enterPortal').classList.add('hidden');
  document.getElementById('exhibitionContainer').classList.add('active');
  document.getElementById('systemTitle').style.display = 'block';
  
  // Wait a bit before starting the text so it's not instant
  setTimeout(() => {
    phase1Typing = true;
  }, 2000); // if it starts immediatly its super distracting with the animation as well
}

// Setup the ENTER button when page loads. DOM DOM DOM
document.addEventListener('DOMContentLoaded', function() {
  const enterButton = document.getElementById('enterButton');
  if (enterButton) {
    enterButton.addEventListener('click', startExhibition);
  }
});

// Main update - called every frame from the game.
function updateExhibition() {
  if (!exhibitionStarted) return;
  
  // Check which phase we're in and run the right typewriter
  if (!phase2Active) {
    typewriterPhase1();
  } else {
    typewriterPhase2();
  }
}

// PHASE 1 TYPEWRITER 
// Types out paragraphs character by character, then waits for the game loop to advance
function typewriterPhase1() {
  // Check if we've shown all 8 paragraphs
  if (phase1Index >= narrativePhase1.length) {
    // Special handling for end of section 8
    // Need to pause for 7 seconds with text visible, then 3 seconds blank
    if (phase1PauseActive) {
      const now = millis();
      if (now - phase1PauseStart >= phase1PauseDuration) {
        if (phase1BlankAfterPause) {
          // Just finished 7 second pause, now do 3 second blank
          phase1BlankAfterPause = false;
          phase1PauseStart = millis();
          phase1PauseDuration = 3000;
          
          const textElement = document.getElementById('narrativeText');
          if (textElement) {
            textElement.textContent = '';
          }
        } else {
          // Finished both pauses, move to Phase 2
          phase1PauseActive = false;
          phase2Active = true;
          phase2Typing = true;
        }
      }
      return;
    }
    
    // Start the 7 second pause if we haven't yet
    if (!phase1PauseActive) {
      phase1PauseActive = true;
      phase1PauseStart = millis();
      phase1PauseDuration = 7000;
      phase1BlankAfterPause = true;
    }
    return;
  }
  
  // Don't type if we're waiting for next loop
  if (phase1WaitingForLoop) return;
  if (!phase1Typing) return;
  
  const now = millis();
  const currentText = narrativePhase1[phase1Index];
  const typeSpeed = 50; //slw
  
  // one character at a time
  if (phase1CharIndex < currentText.length) {
    if (now - phase1LastTypeTime >= typeSpeed) {
      const textElement = document.getElementById('narrativeText');
      if (textElement) {
        textElement.textContent = currentText.substring(0, phase1CharIndex + 1);
        phase1CharIndex++;
        phase1LastTypeTime = now;
      }
    }
  } else {
    // Finished typing this paragraph, wait for next loop
    phase1WaitingForLoop = true;
  }
}

// Called from the game when a loop completes
// Advancs to the next paragraph every 2 loops
function advanceNarrative() {
  if (!exhibitionStarted) return;
  
  if (!phase2Active) {
    // Phase 1: count loops and advance every 2
    phase1LoopsSinceText++;
    
    if (phase1WaitingForLoop && phase1LoopsSinceText >= 2) {
      phase1Index++;
      phase1CharIndex = 0;
      phase1WaitingForLoop = false;
      phase1LoopsSinceText = 0;
      
      // Clear the terminal for next paragraph
      const textElement = document.getElementById('narrativeText');
      if (textElement) {
        textElement.textContent = '';
      }
      
     
      if (phase1Index >= narrativePhase1.length + 1) {
        phase2Active = true;
        phase2Typing = true;
      }
    }
  } else {
    // doesnt sync with loops anymore
    // keeping this here in case I need it later
    const currentSection = narrativePhase2Sections[phase2SectionIndex];
    if (currentSection && currentSection.ellipsisLoops) {
      phase2EllipsisLoops++;
      if (phase2EllipsisLoops >= currentSection.ellipsisLoops) {
        advancePhase2Sentence();
        phase2EllipsisLoops = 0;
      }
    }
  }
}

// PHASE 2 
// More complex - each sentence has its own timing
// Each sentence has its own pause timing and I had to use objects to track everything
// Took forever to get the pauses syncing right but it works now
function typewriterPhase2() {
  // Check if we've done all the Phase 2 sentences
  if (phase2SectionIndex >= narrativePhase2Sections.length) {
    // Wait, dramatic pause! then restart the whole thing
    if (!narrativeFullyComplete) {
      setTimeout(() => {
        resetNarrative();
      }, 100);
      narrativeFullyComplete = true;
    }
    return;
  }
  
  const currentSection = narrativePhase2Sections[phase2SectionIndex];
  if (!currentSection) return;
  
  // Handle pauses between sentences
  if (phase2PauseActive) {
    const now = millis();
    if (now - phase2PauseStart >= phase2PauseDuration) {
      phase2PauseActive = false;
      
      // Move to next 
      phase2SectionIndex++;
      phase2CharIndex = 0;
      phase2Typing = true;
      
      // Clear for next
      const textElement = document.getElementById('narrativeText');
      if (textElement) {
        textElement.textContent = '';
      }
      
      // Turn off red border if it was on lol
      const terminal = document.querySelector('.terminal');
      if (terminal && terminal.classList.contains('terminal-flash')) {
        terminal.classList.remove('terminal-flash');
      }
    }
    return;
  }
  
  //./ Type the current sentene
  if (!phase2Typing) return;
  
  const currentSentence = currentSection.sentences[0];
  const now = millis();
  
  // Different typing speeds based on context
  let typeSpeed = 40; // normal
  if (currentSection.codeSequence) {
    typeSpeed = 15; // fast terminal output
  } else if (currentSection.panic) {
    // erratic panic typing - this was so smart, i had to like think how to make it look sentient
    typeSpeed = random() < 0.4 ? 20 : 35;
  }
  
  // Handle blank sections (just pause, no typing)
  if (currentSection.isBlank || currentSentence === "") {
    phase2PauseActive = true;
    phase2PauseStart = millis();
    phase2PauseDuration = currentSection.pauseAfter || 0;
    phase2Typing = false;
    return;
  }
  
  // Type character by character
  if (phase2CharIndex < currentSentence.length) {
    if (now - phase2LastTypeTime >= typeSpeed) {
      const textElement = document.getElementById('narrativeText');
      if (textElement) {
        textElement.textContent = currentSentence.substring(0, phase2CharIndex + 1);
        phase2CharIndex++;
        phase2LastTypeTime = now;
      }
    }
  } else {
    // Sentence done typing, start the pause
    phase2PauseActive = true;
    phase2PauseStart = millis();
    phase2PauseDuration = currentSection.pauseAfter || 0;
    phase2Typing = false;
    
    // Turn on red border for system failure
    if (currentSection.flashTerminal) {
      const terminal = document.querySelector('.terminal');
      if (terminal) {
        terminal.classList.add('terminal-flash');
      }
    }
  }
}

// Helper function, could commme out, i think this is old and useless now
function advancePhase2Sentence() {
  const currentSection = narrativePhase2Sections[phase2SectionIndex];
  if (!currentSection) return;
  
  phase2SentenceIndex++;
  phase2CharIndex = 0;
  
  if (phase2SentenceIndex >= currentSection.sentences.length) {
    advancePhase2Section();
  } else {
    phase2Typing = true;
  }
}

// Helper function (helper functions were something completely new to me until this project, and it was a big hurdle tbh, might sounds weird but true)
function advancePhase2Section() {
  phase2SectionIndex++;
  phase2SentenceIndex = 0;
  phase2CharIndex = 0;
  phase2Typing = true;
  
  const textElement = document.getElementById('narrativeText');
  if (textElement) {
    textElement.textContent = '';
  }
}

// Reset everything back to the beginning
function resetNarrative() {
  // Phase 1 reset
  phase1Index = 0;
  phase1CharIndex = 0;
  phase1Typing = true;
  phase1WaitingForLoop = false;
  phase1LoopsSinceText = 0;
  phase1PauseActive = false;
  phase1PauseStart = 0;
  phase1PauseDuration = 0;
  phase1BlankAfterPause = false;
  
  // /Phase 2 reset
  phase2Active = false;
  phase2SectionIndex = 0;
  phase2SentenceIndex = 0;
  phase2CharIndex = 0;
  phase2Typing = false;
  phase2PauseActive = false;
  phase2EllipsisLoops = 0;
  
  narrativeFullyComplete = false;
  
  // Clear display
  const textElement = document.getElementById('narrativeText');
  if (textElement) {
    textElement.textContent = '';
  }
  
  // Turn off red border
  const terminal = document.querySelector('.terminal');
  if (terminal) {
    terminal.classList.remove('terminal-flash');
  }
}

// Updates the loop counter display 
function updateLoopCounter(count) {
  const elem = document.getElementById('loopCounter');
  if (elem) {
    elem.textContent = String(count).padStart(3, '0');
  }
}
