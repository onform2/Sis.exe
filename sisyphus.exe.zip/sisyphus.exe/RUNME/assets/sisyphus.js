// ═══════════════════════════════════════════════════════════════════════
// SISYPHUS.EXE - MAIN GAME LOGIC
// ═══════════════════════════════════════════════════════════════════════

let bgImage, knightSheet, monsterSheet;
let pixelBlockSheet, matrixSheet, explosionSheet, smokeSheet;
let floorBreakSheet, crack1, crack2, crack3, crack4, wallsBroken;
let infinitySprite, heartSprite;
let knightGraphics;

// DISPLAY CONSTANTS (4× scale for better screen fit)
const SCALE = 4;
const BG_WIDTH = 496;
const BG_HEIGHT = 133;
const DISPLAY_WIDTH = BG_WIDTH * SCALE;   // 1984px
const DISPLAY_HEIGHT = BG_HEIGHT * SCALE; // 532px

// KNIGHT CONSTANTS
const KNIGHT_START_X_BG = 9; // 15px left (was 24)
const KNIGHT_START_Y_BG = 66;
const KNIGHT_START_X = KNIGHT_START_X_BG * SCALE;
const KNIGHT_START_Y = KNIGHT_START_Y_BG * SCALE;

// MONSTER CONSTANTS  
const MONSTER_X_BG = 394;
const MONSTER_Y_BG = 35;
const MONSTER_X = MONSTER_X_BG * SCALE;
const MONSTER_Y = MONSTER_Y_BG * SCALE;

// KNIGHT SPRITE DATA - Each sprite is in a 100x150 box on the sheet
// Just need the X position of each box (Y is always 0, box is full height)
const knightSprites = {
  idle1: { x: 0, y: 0, w: 100, h: 150 },
  idle2: { x: 100, y: 0, w: 100, h: 150 },
  swordUp1: { x: 200, y: 0, w: 100, h: 150 },
  swordUp2: { x: 300, y: 0, w: 100, h: 150 },
  run1: { x: 400, y: 0, w: 100, h: 150 },
  run2: { x: 500, y: 0, w: 100, h: 150 },
  run3: { x: 600, y: 0, w: 100, h: 150 },
  run4: { x: 700, y: 0, w: 100, h: 150 },
  run5: { x: 800, y: 0, w: 100, h: 150 },
  run6: { x: 900, y: 0, w: 100, h: 150 },
  jumpPrep: { x: 1000, y: 0, w: 100, h: 150 },  // Frame 11 (sprite 7 from sword)
  jump1: { x: 1100, y: 0, w: 100, h: 150 },     // Frame 12
  jump2: { x: 1200, y: 0, w: 100, h: 150 },     // Frame 13
  jump3: { x: 1300, y: 0, w: 100, h: 150 },     // Frame 14
  jump5: { x: 1400, y: 0, w: 100, h: 150 },     // Frame 15
  neverending: { x: 1500, y: 0, w: 100, h: 150 } // Frame 16
};

// MONSTER SPRITE DATA
const monsterSprites = {
  blink1: { x: 1, y: 5, w: 98, h: 91 },
  blink2: { x: 101, y: 5, w: 98, h: 91 },
  blink3: { x: 201, y: 5, w: 98, h: 91 },
  blink4: { x: 301, y: 6, w: 98, h: 90 },
  blink5: { x: 401, y: 6, w: 98, h: 90 },
  blink6: { x: 501, y: 6, w: 98, h: 90 },
  idle1: { x: 601, y: 6, w: 98, h: 90 },
  idle2: { x: 701, y: 5, w: 98, h: 91 },
  shock1: { x: 801, y: 6, w: 98, h: 90 },
  shock2: { x: 901, y: 6, w: 98, h: 90 },
  shock3: { x: 1001, y: 5, w: 98, h: 91 }
};

// GAME STATE
let gameState = 'spawning'; // Start with spawn cloud
let stateStartTime = 0;
let loopCount = 0;
let resetPauseStart = 0; // Track when reset pause started

// KNIGHT STATE
let knightX = KNIGHT_START_X;
let knightY = KNIGHT_START_Y;
let knightVelocity = 0;
let maxSpeed = 3.5;
let accelerationTime = 0.8;
let currentKnightFrame = 0;
let runFrameIndex = 0;

// MONSTER STATE
let monsterFrame = 0;
let monsterBlinkTimer = 0;
let monsterShocked = false;
let monsterShockedFrame = 0;

// STRIKE EVENT SETTINGS
let strikeDistance = 55; // How close to monster before strike
let strikeChance = 0.003; // 0.3% chance per frame - same as glitch triggers
let strikeEnabled = true; // Strike event enabled
let strikeFreezeEnabled = true;
let strikeShakeIntensity = 5;

// GLITCH STATE
let glitchActive = false;
let currentGlitch = null;
let glitchProgress = 0;
let glitchStruggleSpeed = 1.0;
let floorCollapsePhase = 0; // 0-4 for floor breaking animation

// VISUAL EFFECTS
let screenShakeIntensity = 0;
let matrixDrops = [];
let pixelFragments = [];
let spawnCloud = null; // Single cloud object, not array
let crackLevel = 0; // 0-4 for crack progression
let radialBurst = null; // {frame, x, y, life}

// EFFECT TOGGLES
let showSpawnCloud = true;
let showPixelExplosion = true;
let showRadialBurst = false; // Alternative to pixel explosion
let showCracks = false;

// AUDIO
let musicTrack;
let ambienceTrack;
let swordSound;
let matrixSound;
let breakingRocksSound;
let knightRunningSound;
let spawnSound; // Contains atmospheric riser + smoke sound
let riserClimaxSound; // Explosion climax sound
let lagSpikeSound;
let rgbGlitchSound;
let pixelBurstSound;
let timeFreezeSound;
let noiseStormSound;
let screenTearSound;
let invertColoursSound;
let scanLinesSound;
let dataMoshSound;
let gravitySurgeSound;
let vhsGlitchSound;
let modelNotFoundSound;
let resoCollapseSound;
let isMuted = false;
let soundsLoaded = false;
let pixelExplosionEndTime = null; // Track pause after pixel explosion
let pixelExplosionTriggered = false; // Prevent re-triggering explosion
let pixelBurstSoundPlayed = false; // Track if pixel burst sound has played
let floorCollapseSoundPlayed = false; // Track if breaking rocks sound played
let climaxSoundPlayed = false; // Track if riser climax has played
let lagSpikeSoundPlayed = false; // Track if lag spike sound played
let rgbGlitchSoundPlayed = false; // Track if RGB glitch sound played
let timeFreezeSoundPlayed = false; // Track if time freeze sound played
let noiseStormSoundPlayed = false; // Track if noise storm sound played
let screenTearSoundPlayed = false; // Track if screen tear sound played
let invertColoursSoundPlayed = false; // Track if invert colours sound played
let scanLinesSoundPlayed = false; // Track if scan lines sound played
let dataMoshSoundPlayed = false; // Track if data mosh sound played
let gravitySurgeSoundPlayed = false; // Track if gravity surge sound played
let vhsGlitchSoundPlayed = false; // Track if VHS glitch sound played
let modelNotFoundSoundPlayed = false; // Track if model not found sound played
let resoCollapseSoundPlayed = false; // Track if resolution collapse sound played
let knightFlippedBackwards = false; // For lag spike backwards running

// TIMING
const IDLE1_DURATION = 2000;      // 2 seconds breathing at spawn
const SWORD_UP_DURATION = 2000;   // 2 seconds breathing with sword up
const STRIKE_PAUSE_DURATION = 800; // 0.8 second dramatic pause before strike
const SPAWN_CLOUD_DURATION = 800;  // How long spawn cloud shows
const RESET_PAUSE_DURATION = 1000; // 1 second pause before respawn

function preload() {
  bgImage = loadImage('assets/Background_Sprite_FINAL.png');
  knightSheet = loadImage('assets/knight_master_sheet.png');
  monsterSheet = loadImage('assets/monster_master_sheet.png');
  pixelBlockSheet = loadImage('assets/Pixel_block_sprite.png');
  matrixSheet = loadImage('assets/Matrix_sprites.png');
  explosionSheet = loadImage('assets/Radial_explosion_sheet.png');
  smokeSheet = loadImage('assets/Smoke_sprite.png');
  floorBreakSheet = loadImage('assets/floor_breaking_sprite.png');
  crack1 = loadImage('assets/crack_1.png');
  crack2 = loadImage('assets/crack_2.png');
  crack3 = loadImage('assets/crack_3.png');
  crack4 = loadImage('assets/crack_4.png');
  wallsBroken = loadImage('assets/background_broken_walls.png');
  
  // UI sprites
  infinitySprite = loadImage('assets/infinity_sprite.png');
  heartSprite = loadImage('assets/heart_sprite.png');
  
  // Load sounds
  soundFormats('wav', 'mp3', 'ogg');
  musicTrack = loadSound('assets/sounds/16bit_Prok.wav', 
    () => { console.log('Music loaded'); },
    (err) => { console.log('Music load failed', err); }
  );
  ambienceTrack = loadSound('assets/sounds/Background_Sound.wav',
    () => { console.log('Ambience loaded'); },
    (err) => { console.log('Ambience load failed', err); }
  );
  swordSound = loadSound('assets/sounds/Sword.wav',
    () => { console.log('Sword sound loaded'); },
    (err) => { console.log('Sword sound load failed', err); }
  );
  matrixSound = loadSound('assets/sounds/matrix.wav',
    () => { console.log('Matrix sound loaded'); },
    (err) => { console.log('Matrix sound load failed', err); }
  );
  breakingRocksSound = loadSound('assets/sounds/breaking_rocks.wav',
    () => { console.log('Breaking rocks sound loaded'); },
    (err) => { console.log('Breaking rocks sound load failed', err); }
  );
  knightRunningSound = loadSound('assets/sounds/knight_running.wav',
    () => { console.log('Knight running sound loaded'); },
    (err) => { console.log('Knight running sound load failed', err); }
  );
  spawnSound = loadSound('assets/sounds/riser_spawn.wav',
    () => { console.log('Spawn sound loaded'); },
    (err) => { console.log('Spawn sound load failed', err); }
  );
  riserClimaxSound = loadSound('assets/sounds/riser_climax.wav',
    () => { console.log('Riser climax sound loaded'); },
    (err) => { console.log('Riser climax sound load failed', err); }
  );
  lagSpikeSound = loadSound('assets/sounds/lag_spike.wav',
    () => { console.log('Lag spike sound loaded'); },
    (err) => { console.log('Lag spike sound load failed', err); }
  );
  rgbGlitchSound = loadSound('assets/sounds/rgb_glitch.wav',
    () => { console.log('RGB glitch sound loaded'); },
    (err) => { console.log('RGB glitch sound load failed', err); }
  );
  pixelBurstSound = loadSound('assets/sounds/pixel_burst.wav',
    () => { console.log('Pixel burst sound loaded'); },
    (err) => { console.log('Pixel burst sound load failed', err); }
  );
  timeFreezeSound = loadSound('assets/sounds/time_freeze.wav',
    () => { console.log('Time freeze sound loaded'); },
    (err) => { console.log('Time freeze sound load failed', err); }
  );
  noiseStormSound = loadSound('assets/sounds/noise_storm.wav',
    () => { console.log('Noise storm sound loaded'); },
    (err) => { console.log('Noise storm sound load failed', err); }
  );
  screenTearSound = loadSound('assets/sounds/screen_tear.wav',
    () => { console.log('Screen tear sound loaded'); },
    (err) => { console.log('Screen tear sound load failed', err); }
  );
  invertColoursSound = loadSound('assets/sounds/invert_colours.wav',
    () => { console.log('Invert colours sound loaded'); },
    (err) => { console.log('Invert colours sound load failed', err); }
  );
  scanLinesSound = loadSound('assets/sounds/scan_lines.wav',
    () => { console.log('Scan lines sound loaded'); },
    (err) => { console.log('Scan lines sound load failed', err); }
  );
  dataMoshSound = loadSound('assets/sounds/data_mosh.wav',
    () => { console.log('Data mosh sound loaded'); },
    (err) => { console.log('Data mosh sound load failed', err); }
  );
  gravitySurgeSound = loadSound('assets/sounds/gravity_surge.wav',
    () => { console.log('Gravity surge sound loaded'); },
    (err) => { console.log('Gravity surge sound load failed', err); }
  );
  vhsGlitchSound = loadSound('assets/sounds/vhs_glitch.wav',
    () => { console.log('VHS glitch sound loaded'); },
    (err) => { console.log('VHS glitch sound load failed', err); }
  );
  modelNotFoundSound = loadSound('assets/sounds/model_not_found.wav',
    () => { console.log('Model not found sound loaded'); },
    (err) => { console.log('Model not found sound load failed', err); }
  );
  resoCollapseSound = loadSound('assets/sounds/reso_collapse.wav',
    () => { console.log('Resolution collapse sound loaded'); },
    (err) => { console.log('Resolution collapse sound load failed', err); }
  );
}

function setup() {
  let canvas = createCanvas(DISPLAY_WIDTH, DISPLAY_HEIGHT);
  canvas.parent('canvasWrapper'); // Attach to exhibition container
  noSmooth();
  frameRate(60);
  stateStartTime = millis();
  initMatrixDrops();
  
  // Initialize spawn cloud if starting in spawning state
  if (gameState === 'spawning' && showSpawnCloud) {
    initSpawnCloud();
  }
  
  knightGraphics = createGraphics(100 * SCALE, 150 * SCALE); // Full sprite size: 100x150
  knightGraphics.noSmooth();
  
  // Enable audio context (required by browsers)
  userStartAudio();
  
  // Start music and ambience after short delay
  setTimeout(() => {
    if (musicTrack && ambienceTrack && !musicTrack.isPlaying()) {
      musicTrack.loop();
      musicTrack.setVolume(0.7);
      
      ambienceTrack.loop();
      ambienceTrack.setVolume(0.2); // Quiet ambience
      
      soundsLoaded = true;
      console.log('Audio started');
    }
  }, 100);
}

function draw() {
  // Exhibition mode updates
  if (typeof updateExhibition === 'function') {
    updateExhibition();
  }
  
  push();
  
  // Screen shake
  if (screenShakeIntensity > 0) {
    translate(
      random(-screenShakeIntensity, screenShakeIntensity),
      random(-screenShakeIntensity, screenShakeIntensity)
    );
    screenShakeIntensity *= 0.9;
    if (screenShakeIntensity < 0.1) screenShakeIntensity = 0;
  }
  
  // Draw background (STATIC!)
  // Fade during matrix code, then linger in black
  if (glitchActive && currentGlitch === 'matrixCode') {
    // Fill with black first
    background(0);
    
    // Fade background over 0-85%, then stay black for final 15%
    if (glitchProgress < 0.85) {
      let fadeAmount = map(glitchProgress, 0, 0.85, 255, 0); // Fade over 85%
      push();
      tint(255, fadeAmount);
      image(bgImage, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
      pop();
    }
    // After 85% (21.25s), pure black for remaining ~3.75s
  } else {
    image(bgImage, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  }
  
  // Draw cracks if floor collapse is active OR manual cracks enabled
  if ((currentGlitch === 'floorCollapse' && glitchActive) || (showCracks && crackLevel > 0)) {
    drawCracks();
  }
  
  // Update states
  if (!glitchActive) {
    updateGameState();
  } else {
    updateGlitch();
  }
  
  // Update monster
  updateMonster();
  
  // Draw spawn cloud if spawning
  if (gameState === 'spawning' && spawnCloud) {
    drawSpawnCloud();
  }
  
  // Draw knight
  drawKnight();
  
  // Draw pixel fragments if active
  if (pixelFragments.length > 0) {
    drawPixelFragments();
  }
  
  // Draw radial burst if active
  if (radialBurst) {
    drawRadialBurst();
  }
  
  // Draw monster
  drawMonster();
  
  // Draw glitch overlays
  if (glitchActive) {
    drawOverlayEffects();
  }
  
  pop();
  
  // Draw UI elements (hearts, infinity)
  drawUIElements();
  
  // Update UI and running sound
  updateUI();
  updateRunningSound();
}

function updateGameState() {
  let elapsed = millis() - stateStartTime;
  
  switch (gameState) {
    case 'resetting':
      // Pause before respawn
      if (millis() - resetPauseStart >= RESET_PAUSE_DURATION) {
        gameState = showSpawnCloud ? 'spawning' : 'idle1';
        stateStartTime = millis();
        if (showSpawnCloud) {
          initSpawnCloud();
        }
      }
      break;
      
    case 'spawning':
      // Show spawn cloud animation
      if (elapsed >= SPAWN_CLOUD_DURATION) {
        gameState = 'idle1';
        stateStartTime = millis();
      }
      break;
      
    case 'idle1':
      if (elapsed >= IDLE1_DURATION) {
        gameState = 'swordUp';
        stateStartTime = millis();
        // Play sword sound when raising sword
        if (swordSound && !isMuted) {
          swordSound.setVolume(0.6); // Lower volume
          swordSound.play();
        }
      }
      break;
      
    case 'swordUp':
      if (elapsed >= SWORD_UP_DURATION) {
        gameState = 'accelerating';
        stateStartTime = millis();
      }
      break;
      
    case 'accelerating':
      let accelProgress = elapsed / (accelerationTime * 1000);
      if (accelProgress >= 1.0) {
        gameState = 'running';
        knightVelocity = maxSpeed;
      } else {
        knightVelocity = maxSpeed * easeOutQuad(accelProgress);
      }
      knightX += knightVelocity;
      
      // Random chance to trigger glitch
      if (random() < 0.002) {
        triggerRandomGlitch();
      }
      break;
      
    case 'running':
      knightX += knightVelocity;
      
      // Check for strike event (rare)
      if (strikeEnabled && random() < strikeChance) {
        gameState = 'approachingStrike';
        stateStartTime = millis();
      }
      // Or check if close enough for regular glitch
      else if (knightX > MONSTER_X - 200 * SCALE) {
        triggerRandomGlitch();
      }
      
      // Random chance to trigger glitch during run
      if (random() < 0.003) {
        triggerRandomGlitch();
      }
      break;
      
    case 'approachingStrike':
      // Continue running until 100px from monster to start leap
      knightX += knightVelocity;
      if (knightX > MONSTER_X - 100 * SCALE) {
        gameState = 'striking';
        stateStartTime = millis();
        monsterShocked = true;
        monsterShockedFrame = frameCount;
      }
      break;
      
    case 'striking':
      // Slow-motion leap: 6 sprites evenly spaced over 45px (100px to 55px)
      // Each sprite shows for ~300ms, total 1800ms leap
      // Distance per sprite: 45px / 6 = 7.5px
      let strikeElapsed = millis() - stateStartTime;
      let jumpFrame = floor(strikeElapsed / 300); // 300ms per sprite = slow motion
      
      // Play climax sound with offset so climax at 5861ms hits when radial burst triggers at 4500ms
      // Start at: 5.861 - 4.5 = 1.361 seconds into the audio
      if (!climaxSoundPlayed && riserClimaxSound && !isMuted) {
        riserClimaxSound.play(0, 1, 1, 1.361); // Start at 1.361 seconds in
        climaxSoundPlayed = true;
      }
      
      if (jumpFrame < 6) {
        // Move 7.5px per sprite transition
        let targetX = (MONSTER_X - 100 * SCALE) + (jumpFrame * 7.5 * SCALE);
        knightX = lerp(knightX, targetX, 0.15); // Smooth movement
      } else {
        // Hold at final position (55px from monster)
        knightX = MONSTER_X - 55 * SCALE;
        
        // Trigger background intensity at pause
        if (!document.body.classList.contains('strike-intensity')) {
          document.body.classList.add('strike-intensity');
        }
        
        // EXTENDED intense shake on frame 16 - 3 FULL SECONDS
        if (floor(strikeElapsed / 30) % 2 === 0) { // Faster shake
          screenShakeIntensity = 15; // Much stronger
        }
        
        // Trigger radial burst explosion near the end
        if (strikeElapsed > 4500 && !radialBurst) {
          triggerRadialBurst();
        }
        
        if (strikeElapsed > 4800) { // 1800ms leap + 3000ms hang = dramatic pause
          resetLoop();
        }
      }
      break;
  }
}

function updateMonster() {
  // If monster is shocked, show shock animation
  if (monsterShocked) {
    // Loop between shock2 and shock3 (sprites 10-11) - skip shock1 as it's just a duplicate
    monsterFrame = 9 + floor((frameCount / 15) % 2); // Alternates between 9 and 10 (sprites 10-11)
    return;
  }
  
  monsterBlinkTimer++;
  
  if (monsterBlinkTimer < 60) {
    // Blink sequence (1 second)
    monsterFrame = floor(monsterBlinkTimer / 10) % 6;
  } else if (monsterBlinkTimer < 180) {
    // Idle breathing (2 seconds)
    monsterFrame = 6 + floor((monsterBlinkTimer - 60) / 30) % 2;
  } else {
    monsterBlinkTimer = 0;
  }
}

function drawKnight() {
  // Don't draw knight during spawn cloud, pixel explosion, radial burst, resetting, or pixel explosion pause
  if (gameState === 'spawning' || gameState === 'resetting' || pixelFragments.length > 0 || radialBurst || pixelExplosionEndTime) {
    return;
  }
  
  // Determine sprite
  let sprite;
  
  if (gameState === 'idle1') {
    let breathFrame = floor((frameCount / 30) % 2);
    sprite = breathFrame === 0 ? knightSprites.idle1 : knightSprites.idle2;
  } else if (gameState === 'swordUp') {
    let breathFrame = floor((frameCount / 30) % 2);
    sprite = breathFrame === 0 ? knightSprites.swordUp1 : knightSprites.swordUp2;
  } else if (gameState === 'accelerating' || gameState === 'running' || gameState === 'approachingStrike' || glitchActive) {
    runFrameIndex = floor(frameCount / 8) % 6;
    let runFrames = ['run1', 'run2', 'run3', 'run4', 'run5', 'run6'];
    sprite = knightSprites[runFrames[runFrameIndex]];
  } else if (gameState === 'striking') {
    // Strike animation: jumpPrep(11) -> jump1(12) -> jump2(13) -> jump3(14) -> jump5(15) -> neverending(16)
    // Slow motion - 300ms per sprite
    let elapsed = millis() - stateStartTime;
    let jumpIndex = floor(elapsed / 300); // 300ms per frame = slow motion
    
    if (jumpIndex < 6) {
      let jumpFrames = ['jumpPrep', 'jump1', 'jump2', 'jump3', 'jump5', 'neverending'];
      sprite = knightSprites[jumpFrames[jumpIndex]];
    } else {
      // Freeze on neverending (frame 16) with lag/shake
      sprite = knightSprites.neverending;
    }
  } else if (gameState === 'falling') {
    // Show idle animation while falling
    let breathFrame = floor((frameCount / 30) % 2);
    sprite = breathFrame === 0 ? knightSprites.idle1 : knightSprites.idle2;
  }
  
  if (!sprite) sprite = knightSprites.idle1;
  
  // Draw Y position - ONLY use knightY during ACTIVE floor collapse phase 5 (falling) or gravity surge
  // For all other cases, use the fixed position
  let drawY;
  if (glitchActive && currentGlitch === 'floorCollapse' && floorCollapsePhase === 5) {
    drawY = knightY; // Use falling Y position ONLY during active floor collapse
  } else if (glitchActive && currentGlitch === 'gravitySurge') {
    drawY = knightY; // Use bouncing Y position during gravity surge
  } else {
    drawY = -20 * SCALE; // Fixed Y position for everything else
  }
  
  // If glitch active with visual effects, draw to buffer first
  if (glitchActive && (currentGlitch === 'rgbShift' || currentGlitch === 'lagSpike')) {
    // Clear and draw to buffer - buffer is now exactly 100x150 SCALE (full sprite size)
    knightGraphics.clear();
    knightGraphics.image(
      knightSheet,
      0, 0, // No offset needed - buffer matches sprite size
      sprite.w * SCALE, sprite.h * SCALE,
      sprite.x, sprite.y,
      sprite.w, sprite.h
    );
    
    // Apply glitch effect
    applyGlitchToKnight(sprite);
    
    // Draw buffer to screen at knight position
    image(knightGraphics, knightX, drawY);
  } else if (glitchActive && currentGlitch === 'modelNotFound') {
    // MODEL NOT FOUND - Draw fixed 100×100 pink/black checkerboard "missing texture"
    let boxSize = 8 * SCALE; // Small checker squares
    let errorWidth = 100 * SCALE; // Fixed 100px width
    let errorHeight = 100 * SCALE; // Fixed 100px height
    
    // Center horizontally, align bottom with knight's feet, move up 5px
    let errorX = knightX + (sprite.w * SCALE - errorWidth) / 2;
    let errorY = drawY + sprite.h * SCALE - errorHeight - (5 * SCALE); // Bottom aligned, up 5px
    
    push();
    noStroke();
    for (let y = 0; y < errorHeight; y += boxSize) {
      for (let x = 0; x < errorWidth; x += boxSize) {
        // Checkerboard pattern
        let isBlack = (floor(x / boxSize) + floor(y / boxSize)) % 2 === 0;
        fill(isBlack ? color(0, 0, 0) : color(255, 0, 255)); // Black or hot pink
        rect(errorX + x, errorY + y, boxSize, boxSize);
      }
    }
    
    // Add "ERROR" text
    fill(255, 255, 0);
    textFont('Courier New');
    textSize(10);
    textAlign(CENTER);
    text('MODEL', errorX + errorWidth/2, errorY + errorHeight/3);
    text('NOT FOUND', errorX + errorWidth/2, errorY + errorHeight/3 + 14);
    
    // Yellow bounding box
    noFill();
    stroke(255, 255, 0);
    strokeWeight(2);
    rect(errorX, errorY, errorWidth, errorHeight);
    pop();
  } else {
    // Draw directly from sheet - extract full 100x150 box
    
    // Check if knight should be flipped (lag spike backwards running)
    if (knightFlippedBackwards && glitchActive && currentGlitch === 'lagSpike') {
      push();
      translate(knightX + sprite.w * SCALE, drawY); // Translate to flip point
      scale(-1, 1); // Flip horizontally
      image(
        knightSheet,
        0, 0,
        sprite.w * SCALE, sprite.h * SCALE,
        sprite.x, sprite.y,
        sprite.w, sprite.h
      );
      pop();
    } else {
      image(
        knightSheet,
        knightX, drawY,
        sprite.w * SCALE, sprite.h * SCALE,
        sprite.x, sprite.y,
        sprite.w, sprite.h
      );
    }
  }
}

function applyGlitchToKnight(sprite) {
  knightGraphics.loadPixels();
  let pixels = knightGraphics.pixels;
  
  if (currentGlitch === 'rgbShift') {
    // RGB channel separation
    let shift = floor(map(glitchProgress, 0, 1, 0, 20));
    let temp = [...pixels];
    for (let i = 0; i < pixels.length; i += 4) {
      let redIndex = constrain(i - shift * 4, 0, pixels.length - 4);
      let blueIndex = constrain(i + shift * 4, 0, pixels.length - 4);
      pixels[i] = temp[redIndex];
      pixels[i + 2] = temp[blueIndex + 2];
    }
  }
  
  else if (currentGlitch === 'lagSpike') {
    let noiseAmount = map(glitchProgress, 0.5, 1.0, 0, 0.4);
    for (let i = 0; i < pixels.length; i += 4) {
      if (random() < noiseAmount) {
        let gray = random(255);
        pixels[i] = gray;
        pixels[i + 1] = gray;
        pixels[i + 2] = gray;
      }
    }
  }
  
  knightGraphics.updatePixels();
}

function drawMonster() {
  let spriteArray = [
    monsterSprites.blink1, monsterSprites.blink2, monsterSprites.blink3,
    monsterSprites.blink4, monsterSprites.blink5, monsterSprites.blink6,
    monsterSprites.idle1, monsterSprites.idle2,
    monsterSprites.shock1, monsterSprites.shock2, monsterSprites.shock3
  ];
  
  let sprite = spriteArray[monsterFrame] || monsterSprites.idle1;
  
  image(
    monsterSheet,
    MONSTER_X, MONSTER_Y,
    sprite.w * SCALE, sprite.h * SCALE,
    sprite.x, sprite.y,
    sprite.w, sprite.h
  );
}

function drawOverlayEffects() {
  if (currentGlitch === 'rgbShift') {
    // PSYCHEDELIC full-screen RGB shift - FASTER COLOR CYCLING
    let shiftAmount = map(glitchProgress, 0, 1, 0, 15);
    
    // Draw red channel shifted
    push();
    blendMode(ADD);
    tint(255, 0, 0, 120);
    translate(-shiftAmount, 0);
    image(get(), 0, 0);
    pop();
    
    // Draw blue channel shifted
    push();
    blendMode(ADD);
    tint(0, 0, 255, 120);
    translate(shiftAmount, 0);
    image(get(), 0, 0);
    pop();
    
    // Draw green channel shifted vertically
    push();
    blendMode(ADD);
    tint(0, 255, 0, 100);
    translate(0, sin(glitchProgress * TWO_PI * 3) * shiftAmount);
    image(get(), 0, 0);
    pop();
    
    // Add FASTER color cycling overlay - 10x through spectrum
    push();
    blendMode(OVERLAY);
    let hue = (glitchProgress * 360 * 10) % 360; // 10x faster cycling
    colorMode(HSB);
    fill(hue, 90, 100, 40); // More saturated, more opaque
    rect(0, 0, width, height);
    colorMode(RGB);
    pop();
  }
  
  if (currentGlitch === 'matrixCode') {
    // Simple green matrix rain with DRAMATIC density increase at end
    fill(0, 255, 65, map(glitchProgress, 0, 1, 100, 200)); // More opaque
    textFont('Courier New');
    textSize(20); // Bigger, more visible (was 16)
    
    for (let drop of matrixDrops) {
      text(drop.char, drop.x, drop.y);
      drop.y += drop.speed; // Use base speed (removed *2 multiplier)
      if (drop.y > height) {
        drop.y = 0;
        drop.x = random(width);
      }
      if (random() < 0.1) {
        drop.char = random(['0', '1', 'ア', 'イ', 'ウ', 'エ', 'オ']);
      }
    }
    
    // ADD EXTRA LETTERS IN COLUMNS (not random scatter) for stream effect
    if (glitchProgress > 0.6) {
      let columnDensity = floor(map(glitchProgress, 0.6, 1.0, 1, 8)); // 1 to 8 extra letters per column
      for (let drop of matrixDrops) {
        // Draw extra letters above/below each existing drop
        for (let j = 1; j <= columnDensity; j++) {
          let char = random(['0', '1', 'ア', 'イ', 'ウ', 'エ', 'オ']);
          text(char, drop.x, drop.y - (j * 25)); // Space letters 25px apart vertically
          text(char, drop.x, drop.y + (j * 25));
        }
      }
    }
  }
  
  if (glitchProgress > 0.7) {
    fill(255, 0, 0);
    textSize(40);
    textFont('Courier New');
    textAlign(CENTER);
    text('[SYSTEM FAILURE]', width/2, 100);
  }
  
  // NEW GLITCH EFFECTS
  
  if (currentGlitch === 'screenTear') {
    // Horizontal screen tearing
    for (let y = 0; y < height; y += 40) {
      let offset = sin((y + glitchProgress * 500) * 0.1) * glitchProgress * 50;
      copy(0, y, width, 20, offset, y, width, 20);
    }
  }
  
  if (currentGlitch === 'invertColors') {
    // Invert colors with flashing
    if (floor(glitchProgress * 20) % 2 === 0) {
      filter(INVERT);
    }
  }
  
  if (currentGlitch === 'scanLines') {
    // ULTRA INTENSE CRT scan lines
    push();
    stroke(0, map(glitchProgress, 0, 1, 150, 255)); // Much darker/fully opaque
    strokeWeight(3); // Even thicker lines
    for (let y = 0; y < height; y += 2) { // Every 2px = very dense
      line(0, y, width, y);
    }
    // Heavy flickering overlay
    if (floor(glitchProgress * 50) % 2 === 0) {
      fill(0, 80);
      rect(0, 0, width, height);
    }
    pop();
  }
  
  if (currentGlitch === 'chromaticAberration') {
    // Heavy chromatic aberration
    let offset = map(glitchProgress, 0, 1, 0, 20);
    push();
    blendMode(SCREEN);
    tint(255, 0, 0);
    image(get(), -offset, -offset);
    tint(0, 255, 255);
    image(get(), offset, offset);
    pop();
  }
  
  if (currentGlitch === 'dataMosh') {
    // Data corruption effect
    loadPixels();
    for (let i = 0; i < pixels.length; i += 4) {
      if (random() < glitchProgress * 0.3) {
        let shift = floor(random(-50, 50)) * 4;
        let newIndex = constrain(i + shift, 0, pixels.length - 4);
        pixels[i] = pixels[newIndex];
        pixels[i + 1] = pixels[newIndex + 1];
        pixels[i + 2] = pixels[newIndex + 2];
      }
    }
    updatePixels();
  }
  
  if (currentGlitch === 'vhsDistortion') {
    // VHS tracking distortion
    push();
    for (let y = 0; y < height; y += 20) {
      let offset = sin(y * 0.1 + glitchProgress * 10) * glitchProgress * 30;
      copy(0, y, width, 20, offset, y, width, 20);
    }
    // Add noise
    loadPixels();
    for (let i = 0; i < pixels.length; i += 4) {
      if (random() < 0.1) {
        pixels[i] = pixels[i + 1] = pixels[i + 2] = random(100, 200);
      }
    }
    updatePixels();
    pop();
  }
  
  if (currentGlitch === 'noiseStorm') {
    // Heavy static noise
    loadPixels();
    let noiseAmount = map(glitchProgress, 0, 1, 0.1, 0.8);
    for (let i = 0; i < pixels.length; i += 4) {
      if (random() < noiseAmount) {
        let val = random(255);
        pixels[i] = val;
        pixels[i + 1] = val;
        pixels[i + 2] = val;
      }
    }
    updatePixels();
  }
  
  if (currentGlitch === 'mirrorWorld') {
    // Single horizontal mirror flip - simple and disorienting
    let canvasCopy = get();
    
    push();
    translate(width / 2, height / 2);
    
    // Just flip once at the start and keep it flipped
    scale(-1, 1); // Horizontal flip throughout entire effect
    
    image(canvasCopy, -width / 2, -height / 2);
    pop();
  }
  
  // NEW GLITCH EFFECTS
  
  if (currentGlitch === 'resolutionCollapse') {
    // Pixelation effect - downsample and upsample the entire canvas
    let pixelationLevel = floor(map(glitchProgress, 0, 1, 1, 20)); // 1 to 20
    
    if (pixelationLevel > 1) {
      // Capture current canvas
      let temp = get();
      
      // Calculate low-res dimensions
      let lowWidth = floor(width / pixelationLevel);
      let lowHeight = floor(height / pixelationLevel);
      
      push();
      // Disable image smoothing for chunky pixels
      drawingContext.imageSmoothingEnabled = false;
      
      // Draw at low resolution then stretch back to full size
      // image(img, dx, dy, dWidth, dHeight, sx, sy, sWidth, sHeight)
      image(temp, 0, 0, lowWidth, lowHeight); // Draw small version
      image(get(0, 0, lowWidth, lowHeight), 0, 0, width, height); // Stretch to full size
      
      pop();
    }
  }
}
function updateGlitch() {
  // Different progression speeds for different effects
  let progressSpeed = 0.005; // Base speed
  
  if (currentGlitch === 'rgbShift') {
    progressSpeed = 0.014; // Faster for RGB - ~6 seconds total
    // Play RGB glitch sound once with lower volume
    if (!rgbGlitchSoundPlayed && rgbGlitchSound && !isMuted) {
      rgbGlitchSound.setVolume(0.4); // Lower volume
      rgbGlitchSound.play();
      rgbGlitchSoundPlayed = true;
    }
  } else if (currentGlitch === 'vhsDistortion' || currentGlitch === 'screenTear') {
    progressSpeed = 0.050; // Much faster - ~2 seconds (was 0.025)
  } else if (currentGlitch === 'noiseStorm') {
    progressSpeed = 0.020; // Faster - ~5 seconds
  } else if (currentGlitch === 'matrixCode') {
    progressSpeed = 0.0033; // Much slower - ~25 seconds for extended void experience
  } else if (currentGlitch === 'mirrorWorld') {
    progressSpeed = 0.004; // Slower - ~20 seconds so knight progresses further
  } else if (currentGlitch === 'floorCollapse') {
    progressSpeed = 0.005; // Slow for dramatic floor collapse
  } else {
    progressSpeed = 0.008; // Medium for other effects (including matrix)
  }
  
  glitchProgress += progressSpeed;
  
  // For pixel explosion, cap progress at 1.0 and wait for pixels to finish
  if (currentGlitch === 'pixelExplosion' && glitchProgress >= 1.0) {
    glitchProgress = 1.0;
  }
  
  // Pixel explosion event
  if (currentGlitch === 'pixelExplosion') {
    // Play sound at 43.7% for 1204ms buildup before explosion at 80%
    // At 0.005 speed: 43.7% = ~1.46s, 80% = ~2.67s, difference = 1.204s
    if (glitchProgress >= 0.437 && !pixelBurstSoundPlayed && pixelBurstSound && !isMuted) {
      pixelBurstSound.play(); // Play from beginning for full buildup
      pixelBurstSoundPlayed = true;
    }
    
    // Lag and struggle, then explode into pixels
    if (glitchProgress < 0.3) {
      glitchStruggleSpeed = 0.6;
      if (floor(glitchProgress * 100) % 4 === 0) screenShakeIntensity = 2;
    } else if (glitchProgress < 0.6) {
      glitchStruggleSpeed = 0.3;
      if (floor(glitchProgress * 100) % 3 === 0) screenShakeIntensity = 4;
    } else if (glitchProgress < 0.8) {
      glitchStruggleSpeed = 0.0;
      screenShakeIntensity = 6;
    } else if (glitchProgress >= 0.8 && !pixelExplosionTriggered) {
      // Trigger explosion ONCE (sound already playing with buildup)
      explodeKnightIntoPixels();
      pixelExplosionTriggered = true;
    }
    
    // Don't reset early - let the end logic handle it with proper pause
  }
  // LAG SPIKE - Rubber banding between random positions
  else if (currentGlitch === 'lagSpike') {
    // Play lag spike sound once
    if (!lagSpikeSoundPlayed && lagSpikeSound && !isMuted) {
      lagSpikeSound.play();
      lagSpikeSoundPlayed = true;
    }
    
    // Rapid rubber banding - teleport every 5 frames
    if (frameCount % 5 === 0) {
      let rubberBandState = floor(random(8));
      
      switch(rubberBandState) {
        case 0: // Back at spawn
          knightX = KNIGHT_START_X;
          knightY = KNIGHT_START_Y;
          knightFlippedBackwards = false;
          break;
        case 1: // Strike position
          knightX = MONSTER_X - 100 * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 2: // Mid run position
          knightX = KNIGHT_START_X + 300 * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 3: // Running BACKWARDS (flipped sprite)
          knightX = KNIGHT_START_X + random(100, 300) * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = true; // Flip sprite!
          break;
        case 4: // On ceiling (upside down Y)
          knightX = KNIGHT_START_X + random(100, 400) * SCALE;
          knightY = -400 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 5: // Way ahead
          knightX = MONSTER_X - 200 * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 6: // Random mid position
          knightX = KNIGHT_START_X + random(50, 500) * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 7: // Back to normal running
          // Continue normal movement
          knightFlippedBackwards = false;
          break;
      }
      
      // Heavy shake during rubber banding
      screenShakeIntensity = 8;
    }
    
    // Slow struggle forward between teleports
    glitchStruggleSpeed = 0.4;
  }
  // Floor collapse event handling
  else if (currentGlitch === 'floorCollapse') {
    // Play sound once at the beginning
    if (!floorCollapseSoundPlayed && breakingRocksSound && !isMuted) {
      breakingRocksSound.play();
      floorCollapseSoundPlayed = true;
    }
    
    // Progress through phases with SHUDDERS and PAUSES between cracks
    if (glitchProgress < 0.08) {
      // Shudder before first crack
      floorCollapsePhase = 0;
      crackLevel = 0;
      glitchStruggleSpeed = 0.9;
      if (floor(glitchProgress * 200) % 5 === 0) screenShakeIntensity = 2;
    } else if (glitchProgress < 0.20) {
      // Phase 1: First crack appears, knight struggles
      floorCollapsePhase = 1;
      crackLevel = 1;
      glitchStruggleSpeed = 0.7;
    } else if (glitchProgress < 0.28) {
      // Shudder/pause before second crack
      if (floor(glitchProgress * 200) % 5 === 0) screenShakeIntensity = 3;
    } else if (glitchProgress < 0.42) {
      // Phase 2: Second crack
      floorCollapsePhase = 2;
      crackLevel = 2;
      glitchStruggleSpeed = 0.5;
    } else if (glitchProgress < 0.50) {
      // Shudder/pause before third crack
      if (floor(glitchProgress * 200) % 4 === 0) screenShakeIntensity = 4;
    } else if (glitchProgress < 0.66) {
      // Phase 3: Third crack
      floorCollapsePhase = 3;
      crackLevel = 3;
      glitchStruggleSpeed = 0.3;
    } else if (glitchProgress < 0.74) {
      // Shudder/pause before fourth crack
      if (floor(glitchProgress * 200) % 3 === 0) screenShakeIntensity = 5;
    } else if (glitchProgress < 0.88) {
      // Phase 4: Fourth crack - major damage
      floorCollapsePhase = 4;
      crackLevel = 4;
      glitchStruggleSpeed = 0.1;
    } else {
      // Phase 5: Floor fully broken - knight falls
      floorCollapsePhase = 5;
      glitchStruggleSpeed = 0.0;
      screenShakeIntensity = 6;
      // Knight falls - increase Y gradually
      knightY += 3;
    }
  } else {
    // Original struggle sequence for other glitches
    if (glitchProgress < 0.2) glitchStruggleSpeed = 0.8;
    else if (glitchProgress < 0.4) glitchStruggleSpeed = 0.5;
    else if (glitchProgress < 0.6) glitchStruggleSpeed = 0.3;
    else if (glitchProgress < 0.8) glitchStruggleSpeed = 0.1;
    else glitchStruggleSpeed = 0.0;
    
    // Specific effects for new glitches
    if (currentGlitch === 'timeFreeze' && glitchProgress > 0.5) {
      // Play time freeze sound once
      if (!timeFreezeSoundPlayed && timeFreezeSound && !isMuted) {
        timeFreezeSound.play();
        timeFreezeSoundPlayed = true;
      }
      // Ultra slow motion
      glitchStruggleSpeed = 0.05;
    } else if (currentGlitch === 'noiseStorm') {
      // Loop noise storm sound during entire glitch
      if (!noiseStormSoundPlayed && noiseStormSound && !isMuted) {
        noiseStormSound.loop(); // Loop instead of play
        noiseStormSoundPlayed = true;
      }
    } else if (currentGlitch === 'screenTear') {
      // Play screen tear sound once
      if (!screenTearSoundPlayed && screenTearSound && !isMuted) {
        screenTearSound.play();
        screenTearSoundPlayed = true;
      }
      // Visual handled in overlay
      screenShakeIntensity = floor(glitchProgress * 10);
    } else if (currentGlitch === 'invertColors') {
      // Play invert colours sound once
      if (!invertColoursSoundPlayed && invertColoursSound && !isMuted) {
        invertColoursSound.play();
        invertColoursSoundPlayed = true;
      }
    } else if (currentGlitch === 'scanLines') {
      // Play scan lines sound once
      if (!scanLinesSoundPlayed && scanLinesSound && !isMuted) {
        scanLinesSound.play();
        scanLinesSoundPlayed = true;
      }
    } else if (currentGlitch === 'dataMosh') {
      // Loop data mosh sound during entire glitch
      if (!dataMoshSoundPlayed && dataMoshSound && !isMuted) {
        dataMoshSound.loop(); // Loop instead of play
        dataMoshSoundPlayed = true;
      }
    } else if (currentGlitch === 'gravitySurge') {
      // Play gravity surge sound once
      if (!gravitySurgeSoundPlayed && gravitySurgeSound && !isMuted) {
        gravitySurgeSound.play();
        gravitySurgeSoundPlayed = true;
      }
      // Knight bounces up and down DRAMATICALLY
      let bounceAmount = sin(glitchProgress * 20) * 80 * SCALE; // MUCH bigger (was 30)
      knightY = -20 * SCALE + bounceAmount;
      if (floor(glitchProgress * 50) % 10 === 0) screenShakeIntensity = 5; // More shake
    } else if (currentGlitch === 'vhsDistortion') {
      // Loop VHS glitch sound during entire glitch
      if (!vhsGlitchSoundPlayed && vhsGlitchSound && !isMuted) {
        vhsGlitchSound.setVolume(0.4); // Lower volume (was default 1.0)
        vhsGlitchSound.loop(); // Loop instead of play
        vhsGlitchSoundPlayed = true;
      }
    } else if (currentGlitch === 'resolutionCollapse') {
      // Play resolution collapse sound once
      if (!resoCollapseSoundPlayed && resoCollapseSound && !isMuted) {
        resoCollapseSound.play();
        resoCollapseSoundPlayed = true;
      }
    } else if (currentGlitch === 'modelNotFound') {
      // Play model not found sound once
      if (!modelNotFoundSoundPlayed && modelNotFoundSound && !isMuted) {
        modelNotFoundSound.play();
        modelNotFoundSoundPlayed = true;
      }
    } else if (currentGlitch === 'screenTear') {
      // Visual handled in overlay
      screenShakeIntensity = floor(glitchProgress * 10);
    }
  }
  
  // Slow down knight
  knightVelocity = maxSpeed * glitchStruggleSpeed;
  if (glitchStruggleSpeed > 0) {
    knightX += knightVelocity;
  }
  
  if (glitchProgress >= 1.0) {
    // Stop sounds if they're still playing
    if (currentGlitch === 'invertColors' && invertColoursSound && invertColoursSound.isPlaying()) {
      invertColoursSound.stop();
    }
    if (currentGlitch === 'timeFreeze' && timeFreezeSound && timeFreezeSound.isPlaying()) {
      timeFreezeSound.stop();
    }
    if (currentGlitch === 'noiseStorm' && noiseStormSound && noiseStormSound.isPlaying()) {
      noiseStormSound.stop();
    }
    if (currentGlitch === 'vhsDistortion' && vhsGlitchSound && vhsGlitchSound.isPlaying()) {
      vhsGlitchSound.stop();
    }
    if (currentGlitch === 'dataMosh' && dataMoshSound && dataMoshSound.isPlaying()) {
      dataMoshSound.stop();
    }
    if (currentGlitch === 'modelNotFound' && modelNotFoundSound && modelNotFoundSound.isPlaying()) {
      modelNotFoundSound.stop();
    }
    
    // For pixel explosion, wait for all pixels to settle before resetting
    if (currentGlitch === 'pixelExplosion') {
      if (pixelFragments.length === 0 && glitchProgress >= 1.0) {
        // All pixels faded - reset immediately (no pause)
        resetLoop();
      }
    } else {
      resetLoop();
    }
  }
}

function resetLoop() {
  loopCount++;
  
  // Remove background intensity
  document.body.classList.remove('strike-intensity');
  
  // Update exhibition loop counter
  if (typeof updateLoopCounter === 'function') {
    updateLoopCounter(loopCount);
  }
  
  // Advance narrative to next paragraph
  if (typeof advanceNarrative === 'function') {
    advanceNarrative();
  }
  
  // Legacy display update (if exists)
  const loopElem = document.getElementById('loopCounter');
  if (loopElem) {
    loopElem.textContent = String(loopCount).padStart(3, '0');
  }
  
  glitchActive = false;
  currentGlitch = null;
  glitchProgress = 0;
  glitchStruggleSpeed = 1.0;
  floorCollapsePhase = 0;
  crackLevel = 0;
  pixelExplosionTriggered = false; // Reset explosion flag
  pixelExplosionEndTime = null; // Reset pause timer
  pixelBurstSoundPlayed = false; // Reset pixel burst sound flag
  knightFlippedBackwards = false; // Reset backwards flag
  floorCollapseSoundPlayed = false; // Reset floor collapse sound flag
  climaxSoundPlayed = false; // Reset climax sound flag
  lagSpikeSoundPlayed = false; // Reset lag spike sound flag
  rgbGlitchSoundPlayed = false; // Reset RGB sound flag
  timeFreezeSoundPlayed = false; // Reset time freeze sound flag
  noiseStormSoundPlayed = false; // Reset noise storm sound flag
  screenTearSoundPlayed = false; // Reset screen tear sound flag
  invertColoursSoundPlayed = false; // Reset invert colours sound flag
  scanLinesSoundPlayed = false; // Reset scan lines sound flag
  dataMoshSoundPlayed = false; // Reset data mosh sound flag
  gravitySurgeSoundPlayed = false; // Reset gravity surge sound flag
  vhsGlitchSoundPlayed = false; // Reset VHS glitch sound flag
  modelNotFoundSoundPlayed = false; // Reset model not found sound flag
  resoCollapseSoundPlayed = false; // Reset resolution collapse sound flag
  
  // Stop sounds if still playing
  if (invertColoursSound && invertColoursSound.isPlaying()) {
    invertColoursSound.stop();
  }
  if (timeFreezeSound && timeFreezeSound.isPlaying()) {
    timeFreezeSound.stop();
  }
  if (noiseStormSound && noiseStormSound.isPlaying()) {
    noiseStormSound.stop();
  }
  if (vhsGlitchSound && vhsGlitchSound.isPlaying()) {
    vhsGlitchSound.stop();
  }
  if (dataMoshSound && dataMoshSound.isPlaying()) {
    dataMoshSound.stop();
  }
  if (modelNotFoundSound && modelNotFoundSound.isPlaying()) {
    modelNotFoundSound.stop();
  }
  
  screenShakeIntensity = 20;
  
  knightX = KNIGHT_START_X;
  knightY = KNIGHT_START_Y; // Reset Y position
  knightVelocity = 0;
  
  monsterShocked = false;
  monsterBlinkTimer = 0;
  
  pixelFragments = [];
  radialBurst = null;
  spawnCloud = null;
  
  // Play spawn sound - it's 4756ms total, smoke sound at 3776ms
  // Spawn cloud appears after 1000ms reset pause
  // Spawn sound timing:
  // Sound needs to sync with spawn cloud appearing (1000ms from now)
  // Start at 2.776 seconds into the clip for proper sync
  if (spawnSound && !isMuted) {
    spawnSound.play(0, 1, 0.4, 2.776); // Volume 0.4 (was 1), start at 2.776 seconds
  }
  
  // Enter resetting state with pause
  gameState = 'resetting';
  resetPauseStart = millis();
}

function drawCracks() {
  // Draw progressive cracks based on level
  tint(255, 255);
  if (crackLevel >= 1) image(crack1, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  if (crackLevel >= 2) image(crack2, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  if (crackLevel >= 3) image(crack3, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  if (crackLevel >= 4) image(crack4, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  noTint();
  
  // Draw floor breaking sprite if floor collapse active
  if (currentGlitch === 'floorCollapse' && floorCollapsePhase >= 1 && floorCollapsePhase <= 5) {
    // Floor breaking sprite: 5 frames in 60x60 boxes on 300x60 canvas
    let frameIndex = constrain(floorCollapsePhase - 1, 0, 4);
    let frameX = frameIndex * 60;
    // Draw under knight's feet
    let floorX = knightX;
    let floorY = KNIGHT_START_Y + 75 * SCALE;
    image(floorBreakSheet,
      floorX - 30 * SCALE,
      floorY - 30 * SCALE,
      60 * SCALE,
      60 * SCALE,
      frameX, 0, 60, 60
    );
  }
}


function initSpawnCloud() {
  // Single cloud animation - not particles
  // Smoke sprite: 4 frames in 100x100 boxes on 400x100 canvas
  // Sprites have 5px clearance at bottom
  // Knight feet are at: -20 * SCALE + 150 * SCALE = 130 * SCALE from canvas top
  // Cloud bottom should be 5px above that: 130 * SCALE - 5 * SCALE = 125 * SCALE
  // Cloud is 100px tall, so top should be at: 125 * SCALE - 100 * SCALE = 25 * SCALE
  spawnCloud = {
    frame: 0,
    life: 0,
    x: KNIGHT_START_X + 50 * SCALE, // Center of knight
    y: 25 * SCALE // Position so bottom is 5px above ground
  };
}

function drawSpawnCloud() {
  if (!spawnCloud) return;
  
  // Animate through 4 frames
  spawnCloud.life++;
  spawnCloud.frame = floor(spawnCloud.life / 10) % 4; // Change frame every 10 updates
  
  // Draw single smoke sprite
  let frameX = spawnCloud.frame * 100;
  let size = 100 * SCALE;
  
  image(smokeSheet, 
    spawnCloud.x - size/2, 
    spawnCloud.y, 
    size, 
    size,
    frameX, 0, 100, 100
  );
}

function explodeKnightIntoPixels() {
  // Sound already playing with buildup from earlier trigger
  
  // Stop footsteps when explosion happens
  if (knightRunningSound && knightRunningSound.isPlaying()) {
    knightRunningSound.stop();
  }
  
  pixelFragments = [];
  // Pixel blocks: 15 blocks (5 sizes × 3 colors) in 32x32 boxes on 160x96 canvas
  // Each row is a color (red, blue, green), each column is a size
  
  // Create DOUBLE the explosion pixels - 300 total (was 150)
  let centerX = knightX + 50 * SCALE;
  let centerY = (currentGlitch === 'floorCollapse' && floorCollapsePhase === 5) 
    ? knightY + 40 * SCALE
    : -20 * SCALE + 75 * SCALE;
  
  // Create a denser grid: 20×15 = 300 pixels (was 10×15 = 150)
  for (let y = 0; y < 15; y++) {
    for (let x = 0; x < 20; x++) {
      let colorRow = floor(random(3)); // 0=red, 1=blue, 2=green
      let sizeCol = floor(random(5));  // 0-4 different sizes
      
      pixelFragments.push({
        x: centerX - 50 * SCALE + x * 5 * SCALE,
        y: centerY - 75 * SCALE + y * 10 * SCALE,
        vx: random(-8, 8), // MUCH WIDER spread (was -3, 3)
        vy: random(-10, -0.5), // Higher initial velocity
        gravity: 0.35, // Slightly more gravity
        alpha: 255,
        rotation: random(TWO_PI),
        rotSpeed: random(-0.15, 0.15),
        spriteX: sizeCol * 32,
        spriteY: colorRow * 32,
        size: (sizeCol + 1) * 4 * SCALE,
        bounced: false, // Track if already bounced
        onGround: false // Track if settled on ground
      });
    }
  }
}

function drawPixelFragments() {
  const FLOOR_Y = 510; // Knight's feet level (raised from 530)
  
  for (let i = pixelFragments.length - 1; i >= 0; i--) {
    let frag = pixelFragments[i];
    
    // Update physics
    if (!frag.onGround) {
      frag.x += frag.vx;
      frag.y += frag.vy;
      frag.vy += frag.gravity;
      
      // Floor collision with bounce
      if (frag.y >= FLOOR_Y && !frag.bounced) {
        frag.y = FLOOR_Y;
        frag.vy = -frag.vy * 0.4; // Bounce with 40% energy
        frag.vx *= 0.7; // Friction
        frag.bounced = true;
        
        // Settle if bounce is small
        if (abs(frag.vy) < 1) {
          frag.onGround = true;
          frag.vy = 0;
          frag.vx *= 0.9;
        }
      }
    } else {
      // On ground - slow drift
      frag.vx *= 0.95;
      if (abs(frag.vx) < 0.1) frag.vx = 0;
    }
    
    frag.alpha -= 3.5; // Faster fade (was 1.5)
    frag.rotation += frag.rotSpeed * (frag.onGround ? 0.3 : 1);
    
    // Draw pixel block from sprite sheet
    push();
    translate(frag.x, frag.y);
    rotate(frag.rotation);
    tint(255, frag.alpha);
    imageMode(CENTER);
    image(pixelBlockSheet, 
      0, 0,
      frag.size, frag.size,
      frag.spriteX, frag.spriteY, 32, 32
    );
    imageMode(CORNER);
    pop();
    
    // Remove if faded
    if (frag.alpha <= 0) {
      pixelFragments.splice(i, 1);
    }
  }
  noTint();
}

function drawUIElements() {
  // Draw infinity symbol and single heart in top-left - 2X LARGER
  if (infinitySprite) {
    image(infinitySprite, 20, 20, 100, 100); // 2x size (was 50x50)
  }
  if (heartSprite) {
    image(heartSprite, 130, 20, 100, 100); // 2x size (was 50x50), adjusted X position
  }
}

function triggerRadialBurst() {
  // Center on knight's actual position
  let centerX = knightX + 50 * SCALE;
  let centerY = -20 * SCALE + 75 * SCALE; // Match knight's visual center
  radialBurst = {
    x: centerX,
    y: centerY,
    frame: 0,
    life: 0
  };
  // Massive screen shake when knight explodes
  screenShakeIntensity = 25;
}

function drawRadialBurst() {
  if (!radialBurst) return;
  
  radialBurst.life++;
  radialBurst.frame = floor(radialBurst.life / 12); // 12 frames per sprite = MUCH slower
  
  if (radialBurst.frame >= 7) {
    radialBurst = null;
    return;
  }
  
  // Radial explosion: 7 frames in 120x120 boxes on 840x120 canvas
  let frameX = radialBurst.frame * 120;
  let size = 120 * SCALE * 2.5; // 2.5x BIGGER (was 1.5x)
  
  image(explosionSheet,
    radialBurst.x - size/2,
    radialBurst.y - size/2,
    size, size,
    frameX, 0, 120, 120
  );
}

function triggerRandomGlitch() {
  let glitches = [
    'lagSpike', 
    'matrixCode', 
    'rgbShift', 
    'floorCollapse', 
    'pixelExplosion',
    'screenTear',
    'timeFreeze',
    'gravitySurge',
    'invertColors',
    'scanLines',
    'chromaticAberration',
    'dataMosh',
    'vhsDistortion',
    'noiseStorm',
    'mirrorWorld',
    'modelNotFound',
    'resolutionCollapse'
  ];
  currentGlitch = random(glitches);
  glitchActive = true;
  glitchProgress = 0;
  gameState = 'glitching';
  floorCollapsePhase = 0;
  crackLevel = 0;
  pixelExplosionTriggered = false; // Reset explosion flag
  pixelBurstSoundPlayed = false; // Reset pixel burst sound flag
  floorCollapseSoundPlayed = false; // Reset floor collapse sound flag
  lagSpikeSoundPlayed = false; // Reset lag spike sound flag
  rgbGlitchSoundPlayed = false; // Reset RGB sound flag
  timeFreezeSoundPlayed = false; // Reset time freeze sound flag
  noiseStormSoundPlayed = false; // Reset noise storm sound flag
  screenTearSoundPlayed = false; // Reset screen tear sound flag
  invertColoursSoundPlayed = false; // Reset invert colours sound flag
  scanLinesSoundPlayed = false; // Reset scan lines sound flag
  dataMoshSoundPlayed = false; // Reset data mosh sound flag
  gravitySurgeSoundPlayed = false; // Reset gravity surge sound flag
  vhsGlitchSoundPlayed = false; // Reset VHS glitch sound flag
  modelNotFoundSoundPlayed = false; // Reset model not found sound flag
  resoCollapseSoundPlayed = false; // Reset resolution collapse sound flag
  
  if (currentGlitch === 'matrixCode') {
    initMatrixDrops();
    // Play matrix sound (6002ms duration)
    if (matrixSound && !isMuted) {
      matrixSound.play();
    }
  }
}

function initMatrixDrops() {
  matrixDrops = [];
  for (let i = 0; i < 150; i++) { // More drops (was 80)
    matrixDrops.push({
      x: random(width),
      y: random(-height, 0),
      speed: random(3, 10),
      char: random(['0', '1', 'ア', 'イ', 'ウ'])
    });
  }
}

function updateUI() {
  // Only update if elements exist (for development version)
  const stateElem = document.getElementById('stateDisplay');
  if (stateElem) {
    stateElem.textContent = gameState.toUpperCase();
  }
  
  const distElem = document.getElementById('distanceDisplay');
  if (distElem) {
    distElem.textContent = floor((knightX - KNIGHT_START_X) / SCALE) + 'px';
  }
}

function updateRunningSound() {
  // List of glitches where knight should still have footsteps
  let continuousFootstepGlitches = [
    'floorCollapse', 
    'timeFreeze',
    'invertColors',
    'scanLines',
    'chromaticAberration',
    'mirrorWorld',
    'resolutionCollapse',
    'matrixCode'
  ];
  
  // Play running sound when accelerating, running, approaching strike, or during specific glitches
  let isRunningState = (gameState === 'accelerating' || gameState === 'running' || gameState === 'approachingStrike');
  let isGlitchingWithFootsteps = (gameState === 'glitching' && continuousFootstepGlitches.includes(currentGlitch));
  let shouldPlayRunning = (isRunningState || isGlitchingWithFootsteps) && !isMuted;
  
  if (shouldPlayRunning) {
    if (knightRunningSound && !knightRunningSound.isPlaying()) {
      knightRunningSound.loop();
    }
    
    // Fade volume during matrix code as background fades (simpler than reverb)
    if (currentGlitch === 'matrixCode' && knightRunningSound) {
      // Reduce volume as glitch progresses to create distant/fading effect
      let volumeFade = map(glitchProgress, 0, 1, 0.5, 0.15); // 50% volume to 15%
      knightRunningSound.setVolume(volumeFade);
    } else if (knightRunningSound) {
      // Normal volume for other states (reduced from 1.0 to 0.5)
      knightRunningSound.setVolume(0.5);
    }
  } else {
    if (knightRunningSound && knightRunningSound.isPlaying()) {
      knightRunningSound.stop();
    }
  }
}

function easeInOutQuad(t) {
  return t < 0.5 ? 2 * t * t : 1 - pow(-2 * t + 2, 2) / 2;
}

function easeOutQuad(t) {
  return 1 - (1 - t) * (1 - t); // Starts fast, ends slow - feels more natural
}

// Control functions for UI
function restartSequence() {
  resetLoop();
  loopCount--;
  document.getElementById('loopCounter').textContent = String(loopCount).padStart(3, '0');
}

function triggerFullEvent(glitchType) {
  // Reset and start from beginning
  restartSequence();
  // Skip spawn if enabled
  if (showSpawnCloud) {
    setTimeout(() => {
      gameState = 'idle1';
      stateStartTime = millis();
    }, SPAWN_CLOUD_DURATION);
  }
  // After idle, jump to running
  setTimeout(() => {
    gameState = 'running';
    knightVelocity = maxSpeed;
    knightX = KNIGHT_START_X + 50 * SCALE;
    stateStartTime = millis();
    // Trigger glitch after brief run
    setTimeout(() => {
      currentGlitch = glitchType;
      glitchActive = true;
      glitchProgress = 0;
      gameState = 'glitching';
      floorCollapsePhase = 0;
      crackLevel = 0;
      floorCollapseSoundPlayed = false; // Reset sound flag
      
      if (glitchType === 'matrixCode') {
        initMatrixDrops();
        // Play matrix sound
        if (matrixSound && !isMuted) {
          matrixSound.play();
        }
      }
      
      if (glitchType === 'floorCollapse') {
        // Play breaking rocks sound
        if (breakingRocksSound && !isMuted) {
          breakingRocksSound.play();
        }
        floorCollapseSoundPlayed = true;
      }
    }, 500);
  }, showSpawnCloud ? SPAWN_CLOUD_DURATION + 1000 : 1000);
}

function triggerStrikeEvent() {
  // Reset and start from beginning
  restartSequence();
  // Skip spawn if enabled
  if (showSpawnCloud) {
    setTimeout(() => {
      gameState = 'idle1';
      stateStartTime = millis();
    }, SPAWN_CLOUD_DURATION);
  }
  // After idle, jump to running toward monster
  setTimeout(() => {
    gameState = 'running';
    knightVelocity = maxSpeed;
    knightX = KNIGHT_START_X + 50 * SCALE;
    stateStartTime = millis();
    // Enable strike event temporarily
    let wasEnabled = strikeEnabled;
    strikeEnabled = true;
    // Trigger approach to strike
    setTimeout(() => {
      gameState = 'approachingStrike';
      stateStartTime = millis();
      // Reset strike enabled after
      setTimeout(() => {
        strikeEnabled = wasEnabled;
      }, 3000);
    }, 500);
  }, showSpawnCloud ? SPAWN_CLOUD_DURATION + 1000 : 1000);
}

function testSpawnCloud() {
  gameState = 'spawning';
  stateStartTime = millis();
  initSpawnCloud();
}

function testPixelExplosion() {
  explodeKnightIntoPixels();
}

function testRadialBurst() {
  triggerRadialBurst();
}

function updateStrikeDist(value) {
  strikeDistance = parseInt(value);
  document.getElementById('strikeDistValue').textContent = strikeDistance;
}

function updateStrikeShake(value) {
  strikeShakeIntensity = parseInt(value);
  document.getElementById('strikeShakeValue').textContent = strikeShakeIntensity;
}

function mousePressed() {
  // Ensure audio starts on first click (browser requirement)
  if (!soundsLoaded && musicTrack && ambienceTrack && !musicTrack.isPlaying()) {
    userStartAudio();
    musicTrack.loop();
    musicTrack.setVolume(isMuted ? 0 : 0.7);
    ambienceTrack.loop();
    ambienceTrack.setVolume(isMuted ? 0 : 0.2);
    soundsLoaded = true;
    console.log('Audio started on click');
  }
}

function toggleSpawnCloud(checked) {
  showSpawnCloud = checked;
}

function togglePixelExplosion(checked) {
  showPixelExplosion = checked;
}

function toggleRadialBurst(checked) {
  showRadialBurst = checked;
  if (checked) {
    showPixelExplosion = false; // Disable pixel explosion if radial is on
    document.getElementById('pixelExplosionCheck').checked = false;
  }
}

function toggleMute() {
  isMuted = !isMuted;
  
  if (isMuted) {
    // Mute all sounds
    if (musicTrack) musicTrack.setVolume(0);
    if (ambienceTrack) ambienceTrack.setVolume(0);
    if (knightRunningSound && knightRunningSound.isPlaying()) knightRunningSound.stop();
    document.getElementById('muteButton').innerHTML = '🔇 SOUND OFF';
    document.getElementById('muteButton').style.background = '#ff4444';
    document.getElementById('muteButton').style.color = '#fff';
  } else {
    // Unmute
    if (musicTrack) musicTrack.setVolume(0.7);
    if (ambienceTrack) ambienceTrack.setVolume(0.2);
    document.getElementById('muteButton').innerHTML = '🔊 SOUND ON';
    document.getElementById('muteButton').style.background = '#00ff00';
    document.getElementById('muteButton').style.color = '#000';
  }
}

function toggleCracks(checked) {
  showCracks = checked;
}

function triggerGlitch(type) {
  if (gameState === 'running' || gameState === 'accelerating' || gameState === 'strikePause' || gameState === 'approachingStrike') {
    currentGlitch = type;
    glitchActive = true;
    glitchProgress = 0;
    gameState = 'glitching';
    pixelExplosionTriggered = false; // Reset explosion flag
    
    if (type === 'matrixCode') {
      initMatrixDrops();
    }
  }
}
