// Main game file for Sisyphus.exe
// Handles all the animation, physics, and glitch effects
// actually complicated and tbh the ammount of times i nearly threw in the towel

let bgImage, knightSheet, monsterSheet;
let pixelBlockSheet, matrixSheet, explosionSheet, smokeSheet;
let floorBreakSheet, crack1, crack2, crack3, crack4, wallsBroken;
let infinitySprite, heartSprite;
let knightGraphics;
// Canvas and scaling settings
// Everything is 4x scale so it looks good on modern screens, but the art was made pixel art size
const SCALE = 4;
const BG_WIDTH = 496;
const BG_HEIGHT = 133;
const DISPLAY_WIDTH = BG_WIDTH * SCALE;   // 1984px
const DISPLAY_HEIGHT = BG_HEIGHT * SCALE; // 532px

// Where the knight starts on screen
const KNIGHT_START_X_BG = 9; 
const KNIGHT_START_Y_BG = 66;
const KNIGHT_START_X = KNIGHT_START_X_BG * SCALE;
const KNIGHT_START_Y = KNIGHT_START_Y_BG * SCALE;

// Where the monster sits, forever and ever and ever 
const MONSTER_X_BG = 394;
const MONSTER_Y_BG = 35;
const MONSTER_X = MONSTER_X_BG * SCALE;
const MONSTER_Y = MONSTER_Y_BG * SCALE;

// Knight sprite sheet layout
// Each sprite is in a 100x150 box, laid out horizontally
// Just tracking the x position of each one
const knightSprites = {
  idle1: { x: 0, y: 0, w: 100, h: 150 },
  idle2: { x: 100, y: 0, w: 100, h: 150 },
  swordUp1: { x: 200, y: 0, w: 100, h: 150 },
  swordUp2: { x: 300, y: 0, w: 100, h: 150 },
  run1: { x: 400, y: 0, w: 100, h: 150 },
  run2: { x: 500, y: 0, w: 100, h: 150 },
  run3: { x: 600, y: 0, w: 100, h: 150 },
  run4: { x: 700, y: 0, w: 100, h: 150 },
  run5: { x: 800, y: 0, w: 100, h: 150 },
  run6: { x: 900, y: 0, w: 100, h: 150 },
  jumpPrep: { x: 1000, y: 0, w: 100, h: 150 }, // leap strike frame 1
  jump1: { x: 1100, y: 0, w: 100, h: 150 },     
  jump2: { x: 1200, y: 0, w: 100, h: 150 },     
  jump3: { x: 1300, y: 0, w: 100, h: 150 },     
  jump5: { x: 1400, y: 0, w: 100, h: 150 },     
  neverending: { x: 1500, y: 0, w: 100, h: 150 } //climax (the elusive sprite 16, inside joke)
};

// Monster sprite sheet layout, those little increments of 01. subpixel animation. yeah ikr!
const monsterSprites = {
  blink1: { x: 1, y: 5, w: 98, h: 91 },
  blink2: { x: 101, y: 5, w: 98, h: 91 },
  blink3: { x: 201, y: 5, w: 98, h: 91 },
  blink4: { x: 301, y: 5, w: 98, h: 90 },
  blink5: { x: 401, y: 5, w: 98, h: 90 },
  blink6: { x: 501, y: 5, w: 98, h: 90 },
  idle1: { x: 601, y: 5, w: 98, h: 90 },
  idle2: { x: 701, y: 5, w: 98, h: 91 },
  shock1: { x: 801, y: 5, w: 98, h: 90 }, // when knight gets close
  shock2: { x: 901, y: 5, w: 98, h: 90 },
  shock3: { x: 1001, y: 5, w: 98, h: 91 }
};

// Game state tracking
let gameState = 'spawning'; // starts with spawn cloud effect
let stateStartTime = 0;
let loopCount = 0;
let resetPauseStart = 0;

// Knights movement variables
let knightX = KNIGHT_START_X;
let knightY = KNIGHT_START_Y;
let knightVelocity = 0;
let maxSpeed = 3.5;
let accelerationTime = 0.8;
let currentKnightFrame = 0;
let runFrameIndex = 0;

/// Monsters animation variables
let monsterFrame = 0;
let monsterBlinkTimer = 0;
let monsterShocked = false; // when knight starts leap strike
let monsterShockedFrame = 0;

// Leap strike settings
let strikeDistance = 55; // at what distance from the beast doth the knight freezeth
let strikeChance = 0.0003; //rare!
let strikeEnabled = true;  // turn on/off the strike event (left over from testing or something)
let strikeFreezeEnabled = true;
let strikeShakeIntensity = 5;

// Glitch system variables
let glitchActive = false; 
let currentGlitch = null;
let glitchProgress = 0;
let glitchStruggleSpeed = 1.0;
let floorCollapsePhase = 0; // tracks floor breaking stages, this is a unique event

// Visuel effect
let screenShakeIntensity = 0;
let matrixDrops = [];
let pixelFragments = [];
let spawnCloud = null; 
let crackLevel = 0; //cracklevel amiright
let radialBurst = null;

// Effect toggle
let showSpawnCloud = true;
let showPixelExplosion = true;
let showRadialBurst = false; // Alternative to pixel explosion, ended up using this for the end of the leap strike
let showCracks = false;

// Audio/SOund
let musicTrack;
let ambienceTrack;
let swordSound;
let matrixSound;
let breakingRocksSound;
let knightRunningSound;
let spawnSound; 
let riserClimaxSound; 
let lagSpikeSound;
let rgbGlitchSound;
let pixelBurstSound;
let timeFreezeSound;
let noiseStormSound;
let screenTearSound;
let invertColoursSound;
let scanLinesSound;
let dataMoshSound;
let gravitySurgeSound;
let vhsGlitchSound;
let modelNotFoundSound;
let resoCollapseSound;
let isMuted = false;
let soundsLoaded = false;

//can we get a round of applause for me naming things like a professional, instead of pixelSplodeEndTimage like old me would have

let pixelExplosionEndTime = null; // Track pause
let pixelExplosionTriggered = false; // Prevent re-triggering
let pixelBurstSoundPlayed = false; // Track if sound has played
let floorCollapseSoundPlayed = false;
let climaxSoundPlayed = false; 
let lagSpikeSoundPlayed = false; 
let rgbGlitchSoundPlayed = false; 
let timeFreezeSoundPlayed = false; 
let noiseStormSoundPlayed = false; 
let screenTearSoundPlayed = false; 
let invertColoursSoundPlayed = false; 
let scanLinesSoundPlayed = false; 
let dataMoshSoundPlayed = false; 
let gravitySurgeSoundPlayed = false; 
let vhsGlitchSoundPlayed = false; 
let modelNotFoundSoundPlayed = false; 
let resoCollapseSoundPlayed = false; 
let knightFlippedBackwards = false; 


const IDLE1_DURATION = 2000;
const SWORD_UP_DURATION = 2000;   
const STRIKE_PAUSE_DURATION = 800; 
const SPAWN_CLOUD_DURATION = 800;  
const RESET_PAUSE_DURATION = 1000;

function preload() {
  bgImage = loadImage('assets/Background_Sprite_FINAL.png');
  knightSheet = loadImage('assets/knight_master_sheet.png');
  monsterSheet = loadImage('assets/monster_master_sheet.png');
  pixelBlockSheet = loadImage('assets/Pixel_block_sprite.png');
  matrixSheet = loadImage('assets/Matrix_sprites.png');
  explosionSheet = loadImage('assets/Radial_explosion_sheet.png');
  smokeSheet = loadImage('assets/Smoke_sprite.png');
  floorBreakSheet = loadImage('assets/floor_breaking_sprite.png');
  crack1 = loadImage('assets/crack_1.png');
  crack2 = loadImage('assets/crack_2.png');
  crack3 = loadImage('assets/crack_3.png');
  crack4 = loadImage('assets/crack_4.png');
  wallsBroken = loadImage('assets/background_broken_walls.png');
  infinitySprite = loadImage('assets/infinity_sprite.png');
  heartSprite = loadImage('assets/heart_sprite.png');
  
  //copy paste, copy paste, copy paste, copy paste, copy paste  copy paste, copy paste, copy paste, copy paste, copy paste, copy pasta,
  soundFormats('wav', 'mp3', 'ogg');
  musicTrack = loadSound('assets/sounds/16bit_Prok.wav', 
    () => { console.log('Music loaded'); },
    (err) => { console.log('Music load failed', err); }
  );
  ambienceTrack = loadSound('assets/sounds/Background_Sound.wav',
    () => { console.log('Ambience loaded'); },
    (err) => { console.log('Ambience load failed', err); }
  );
  swordSound = loadSound('assets/sounds/Sword.wav',
    () => { console.log('Sword sound loaded'); },
    (err) => { console.log('Sword sound load failed', err); }
  );
  matrixSound = loadSound('assets/sounds/matrix.wav',
    () => { console.log('Matrix sound loaded'); },
    (err) => { console.log('Matrix sound load failed', err); }
  );
  breakingRocksSound = loadSound('assets/sounds/breaking_rocks.wav',
    () => { console.log('Breaking rocks sound loaded'); },
    (err) => { console.log('Breaking rocks sound load failed', err); }
  );
  knightRunningSound = loadSound('assets/sounds/knight_running.wav',
    () => { console.log('Knight running sound loaded'); },
    (err) => { console.log('Knight running sound load failed', err); }
  );
  spawnSound = loadSound('assets/sounds/riser_spawn.wav',
    () => { console.log('Spawn sound loaded'); },
    (err) => { console.log('Spawn sound load failed', err); }
  );
  riserClimaxSound = loadSound('assets/sounds/riser_climax.wav',
    () => { console.log('Riser climax sound loaded'); },
    (err) => { console.log('Riser climax sound load failed', err); }
  );
  lagSpikeSound = loadSound('assets/sounds/lag_spike.wav',
    () => { console.log('Lag spike sound loaded'); },
    (err) => { console.log('Lag spike sound load failed', err); }
  );
  rgbGlitchSound = loadSound('assets/sounds/rgb_glitch.wav',
    () => { console.log('RGB glitch sound loaded'); },
    (err) => { console.log('RGB glitch sound load failed', err); }
  );
  pixelBurstSound = loadSound('assets/sounds/pixel_burst.wav',
    () => { console.log('Pixel burst sound loaded'); },
    (err) => { console.log('Pixel burst sound load failed', err); }
  );
  timeFreezeSound = loadSound('assets/sounds/time_freeze.wav',
    () => { console.log('Time freeze sound loaded'); },
    (err) => { console.log('Time freeze sound load failed', err); }
  );
  noiseStormSound = loadSound('assets/sounds/noise_storm.wav',
    () => { console.log('Noise storm sound loaded'); },
    (err) => { console.log('Noise storm sound load failed', err); }
  );
  screenTearSound = loadSound('assets/sounds/screen_tear.wav',
    () => { console.log('Screen tear sound loaded'); },
    (err) => { console.log('Screen tear sound load failed', err); }
  );
  invertColoursSound = loadSound('assets/sounds/invert_colours.wav',
    () => { console.log('Invert colours sound loaded'); },
    (err) => { console.log('Invert colours sound load failed', err); }
  );
  scanLinesSound = loadSound('assets/sounds/scan_lines.wav',
    () => { console.log('Scan lines sound loaded'); },
    (err) => { console.log('Scan lines sound load failed', err); }
  );
  dataMoshSound = loadSound('assets/sounds/data_mosh.wav',
    () => { console.log('Data mosh sound loaded'); },
    (err) => { console.log('Data mosh sound load failed', err); }
  );
  gravitySurgeSound = loadSound('assets/sounds/gravity_surge.wav',
    () => { console.log('Gravity surge sound loaded'); },
    (err) => { console.log('Gravity surge sound load failed', err); }
  );
  vhsGlitchSound = loadSound('assets/sounds/vhs_glitch.wav',
    () => { console.log('VHS glitch sound loaded'); },
    (err) => { console.log('VHS glitch sound load failed', err); }
  );
  modelNotFoundSound = loadSound('assets/sounds/model_not_found.wav',
    () => { console.log('Model not found sound loaded'); },
    (err) => { console.log('Model not found sound load failed', err); }
  );
  resoCollapseSound = loadSound('assets/sounds/reso_collapse.wav',
    () => { console.log('Resolution collapse sound loaded'); },
    (err) => { console.log('Resolution collapse sound load failed', err); }
  );
}

function setup() {
  let canvas = createCanvas(DISPLAY_WIDTH, DISPLAY_HEIGHT);
  canvas.parent('canvasWrapper'); 
  noSmooth();
  frameRate(60);
  stateStartTime = millis();
  initMatrixDrops();
  
 
  if (gameState === 'spawning' && showSpawnCloud) {
    initSpawnCloud();
  }
  
  knightGraphics = createGraphics(100 * SCALE, 150 * SCALE);
  knightGraphics.noSmooth();
  

  userStartAudio(); //consential audio, anti jumpscare technology 
  
  // Start music after a short delay
  // Had to do this to get around browser autoplay restrictions
  setTimeout(() => {
    if (musicTrack && ambienceTrack && !musicTrack.isPlaying()) {
      musicTrack.loop();
      musicTrack.setVolume(0.7);
      
      ambienceTrack.loop();
      ambienceTrack.setVolume(0.2); // keep it quiet in background
      
      soundsLoaded = true;
      console.log('Audio started');
    }
  }, 100);
}

function draw() {

  //this was from when I was going from my test version to this build. I accidently called for an old version of p5js in my new html file and all hell broke loose. I was chasing ghosts for 2 days.
    if (frameCount === 60) {
    console.log('Canvas size:', width, 'x', height);
    console.log('Pixel count:', width * height);
  }
 
if (frameCount % 60 === 0) {
  console.log('FPS:', floor(frameRate()));
}

   // Update the narrative text
  if (typeof updateExhibition === 'function') {
    updateExhibition();
  }
  
  push();
  
  // Screen shake
  if (screenShakeIntensity > 0) {
    translate(
      random(-screenShakeIntensity, screenShakeIntensity),
      random(-screenShakeIntensity, screenShakeIntensity)
    );
    screenShakeIntensity *= 0.9;
    if (screenShakeIntensity < 0.1) screenShakeIntensity = 0;
  }
  
  // Draw background
  // Fade during matrix code, then linger in black
  if (glitchActive && currentGlitch === 'matrixCode') {
    // Fill with black first
    background(0);
    
   //This is for the matrix effect, i remember because getting the background to fade was so key to making that one look good
    if (glitchProgress < 0.85) {
      let fadeAmount = map(glitchProgress, 0, 0.85, 255, 0);
      push();
      tint(255, fadeAmount);
      image(bgImage, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
      pop();
    }
  
     // Draw the background
  } else {
    image(bgImage, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  }
  

  if ((currentGlitch === 'floorCollapse' && glitchActive) || (showCracks && crackLevel > 0)) {
    drawCracks();
  }
  
 
  if (!glitchActive) {
    updateGameState();
  } else {
    updateGlitch();
  }
  
  updateMonster();
  
  if (gameState === 'spawning' && spawnCloud) {
    drawSpawnCloud();
  }
  
  drawKnight();
  
  if (pixelFragments.length > 0) {
    drawPixelFragments();
  }
  
  if (radialBurst) {
    drawRadialBurst();
  }
  
  drawMonster();
  
  if (glitchActive) {
    drawOverlayEffects();
  }
  
  pop();
  
  drawUIElements();
  
  updateUI();
  updateRunningSound();
}

function updateGameState() {
   // Update game state (handles all the logic)
  let elapsed = millis() - stateStartTime;
  
  switch (gameState) {
    case 'resetting':
      // Pause before respawn
      if (millis() - resetPauseStart >= RESET_PAUSE_DURATION) {
        gameState = showSpawnCloud ? 'spawning' : 'idle1';
        stateStartTime = millis();
        if (showSpawnCloud) {
          initSpawnCloud();
        }
      }
      break;
      
    case 'spawning':
      // Show spawn cloud animation
      if (elapsed >= SPAWN_CLOUD_DURATION) {
        gameState = 'idle1';
        stateStartTime = millis();
      }
      break;
      
    case 'idle1':
      if (elapsed >= IDLE1_DURATION) {
        gameState = 'swordUp';
        stateStartTime = millis();
        // Play sword sound when raising sword
        if (swordSound && !isMuted) {
          swordSound.setVolume(0.6); // Lower volume
          swordSound.play();
        }
      }
      break;
      
    case 'swordUp':
      if (elapsed >= SWORD_UP_DURATION) {
        gameState = 'accelerating';
        stateStartTime = millis();
      }
      break;
      
    case 'accelerating':
      let accelProgress = elapsed / (accelerationTime * 1000);
      if (accelProgress >= 1.0) {
        gameState = 'running';
        knightVelocity = maxSpeed;
      } else {
        knightVelocity = maxSpeed * easeOutQuad(accelProgress);
      }
      knightX += knightVelocity;
      
      // Random chance to trigger glitch at the begginging before the runningstate
      if (!glitchActive && random() < 0.002) {
        triggerRandomGlitch();
      }
      break;
      
    case 'running':
      knightX += knightVelocity;
      
      if (strikeEnabled && !glitchActive && random() < strikeChance) {
        gameState = 'approachingStrike';
        stateStartTime = millis();
      }
      else if (!glitchActive && knightX > MONSTER_X - 200 * SCALE) {
        triggerRandomGlitch();
      }
      
      // Random chance to trigger glitch during run
      if (!glitchActive && random() < 0.003) {
        triggerRandomGlitch();
      }
      break;
      
    case 'approachingStrike':
      // Continue running until 100px from monster to start leap
      knightX += knightVelocity;
      if (knightX > MONSTER_X - 100 * SCALE) {
        gameState = 'striking';
        stateStartTime = millis();
        monsterShocked = true;
        monsterShockedFrame = frameCount;
      }
      break;
      
    case 'striking':
      // The slow-motion leap animation
// 6 frames over ~1.8 seconds, then freeze on last frame for 3 seconds
// Had to calculate spacing: 45px total / 6 frames = 7.5px per frame
      let strikeElapsed = millis() - stateStartTime;
      let jumpFrame = floor(strikeElapsed / 300);
      
      // Play climax sound with offset so climax at 5861ms hits when radial burst triggers at 4500ms using Audacity to get these times in MS based.
      // Start at: 5.861 - 4.5 = 1.361 seconds into the audio
      if (!climaxSoundPlayed && riserClimaxSound && !isMuted) {
        riserClimaxSound.play(0, 1, 1, 1.361); // Start at 1.361 seconds in
        climaxSoundPlayed = true;
      }
      
      if (jumpFrame < 6) {
        // Move 7.5px per sprite transition
        let targetX = (MONSTER_X - 100 * SCALE) + (jumpFrame * 7.5 * SCALE);
        knightX = lerp(knightX, targetX, 0.15); //lerp for smooth movement
      } else {
        // HOLD at final position (55px from monster)
        knightX = MONSTER_X - 55 * SCALE;
        
        // Trigger background intensity at pause, late edition, final polishing elements
        if (!document.body.classList.contains('strike-intensity')) {
          document.body.classList.add('strike-intensity');
        }
        
        // intense shake 
        if (floor(strikeElapsed / 30) % 2 === 0) { 
          screenShakeIntensity = 15; //many variable like this, are left over from the original html build. This naming convention was from 
                                    //where I had an slider in my window that I could play with differnt numbers inside the beta test
        }
        
        // Trigger radial burst explosion near the end
        if (strikeElapsed > 4500 && !radialBurst) {
          triggerRadialBurst();
        }
        
        if (strikeElapsed > 4800) { ///dramatic pause
          resetLoop();
        }
      }
      break;
  }
}

function updateMonster() {
  // If monster is shocked, show shock animation
  if (monsterShocked) {
    // Loop between shock2 and shock3 (sprites 10-11) - skip shock1 as it's just a duplicate, things like this were just a pain, i could have gone back and
    //edited the photoshop files, but I in fact was too lazy to do so, but in hindsight would have made things easier maybe.
    monsterFrame = 9 + floor((frameCount / 15) % 2); // Alternates between 9 and 10 (sprites 10-11)
    return;
  }
  
  monsterBlinkTimer++;
  
  //this is so that it doesn't just loop blinks back to back. its give some breathing room with the subpixel animation and then another blink. feels a little more natural
  if (monsterBlinkTimer < 60) {
  
    monsterFrame = floor(monsterBlinkTimer / 10) % 6;
  } else if (monsterBlinkTimer < 180) {
  
    monsterFrame = 6 + floor((monsterBlinkTimer - 60) / 30) % 2;
  } else {
    monsterBlinkTimer = 0;
  }
}

function drawKnight() {
  // Don't draw knight during spawn cloud, pixel explosion, radial burst, resetting, or pixel explosion pause, this was a visual issue in the beta
  if (gameState === 'spawning' || gameState === 'resetting' || pixelFragments.length > 0 || radialBurst || pixelExplosionEndTime) {
    return;
  }
  let sprite;
  
  if (gameState === 'idle1') {
    let breathFrame = floor((frameCount / 30) % 2);
    sprite = breathFrame === 0 ? knightSprites.idle1 : knightSprites.idle2;
  } else if (gameState === 'swordUp') {
    let breathFrame = floor((frameCount / 30) % 2);
    sprite = breathFrame === 0 ? knightSprites.swordUp1 : knightSprites.swordUp2;
  } else if (gameState === 'accelerating' || gameState === 'running' || gameState === 'approachingStrike' || glitchActive) {
    runFrameIndex = floor(frameCount / 8) % 6;
    let runFrames = ['run1', 'run2', 'run3', 'run4', 'run5', 'run6'];
    sprite = knightSprites[runFrames[runFrameIndex]];
  } else if (gameState === 'striking') {
    // Strike animation: jumpPrep(11) -> jump1(12) -> jump2(13) -> jump3(14) -> jump5(15) -> neverending(16)
    // Slow motion - 300ms per sprite
    let elapsed = millis() - stateStartTime;
    let jumpIndex = floor(elapsed / 300);
    
    if (jumpIndex < 6) {
      let jumpFrames = ['jumpPrep', 'jump1', 'jump2', 'jump3', 'jump5', 'neverending'];
      sprite = knightSprites[jumpFrames[jumpIndex]];
    } else {
      // Freeze on sprite 16
      sprite = knightSprites.neverending;
    }
  } else if (gameState === 'falling') {
    let breathFrame = floor((frameCount / 30) % 2);
    sprite = breathFrame === 0 ? knightSprites.idle1 : knightSprites.idle2;
  }
  
  if (!sprite) sprite = knightSprites.idle1;
  let drawY;
  if (glitchActive && currentGlitch === 'floorCollapse' && floorCollapsePhase === 5) {
    drawY = knightY; // Use falling Y position ONLY during active floor collapse
  } else if (glitchActive && currentGlitch === 'gravitySurge') {
    drawY = knightY; // Use bouncing Y position during gravity surge
  } else {
    drawY = -20 * SCALE; // Fixed Y position for everything else
  }
  

  if (glitchActive && (currentGlitch === 'rgbShift' || currentGlitch === 'lagSpike')) {
   
    knightGraphics.clear();
    knightGraphics.image(
      knightSheet,
      0, 0,
      sprite.w * SCALE, sprite.h * SCALE,
      sprite.x, sprite.y,
      sprite.w, sprite.h
    );
    
   
    applyGlitchToKnight(sprite);
    
    // Draw buffer to screen at knight position
    image(knightGraphics, knightX, drawY);
  } else if (glitchActive && currentGlitch === 'modelNotFound') {
    // MODEL NOT FOUND - Draw fixed 100×100 pink/black checkerboard "missing texture"
    let boxSize = 8 * SCALE; // Small checker squares
    let errorWidth = 100 * SCALE; // Fixed 100px width
    let errorHeight = 100 * SCALE; // Fixed 100px height
    
    // Center horizontally, align bottom with knight's feet, move up 5px
    let errorX = knightX + (sprite.w * SCALE - errorWidth) / 2;
    let errorY = drawY + sprite.h * SCALE - errorHeight - (5 * SCALE); // Bottom aligned, up 5px
    
    push();
    noStroke();
    for (let y = 0; y < errorHeight; y += boxSize) {
      for (let x = 0; x < errorWidth; x += boxSize) {
        // Checkerboard pattern
        let isBlack = (floor(x / boxSize) + floor(y / boxSize)) % 2 === 0;
        fill(isBlack ? color(0, 0, 0) : color(255, 0, 255)); // Black or hot pink
        rect(errorX + x, errorY + y, boxSize, boxSize);
      }
    }
    
    // Add "ERROR" text
    fill(255, 255, 0);
    textFont('Courier New');
    textSize(10);
    textAlign(CENTER);
    text('MODEL', errorX + errorWidth/2, errorY + errorHeight/3);
    text('NOT FOUND', errorX + errorWidth/2, errorY + errorHeight/3 + 14);
    
    // Yellow bounding box
    noFill();
    stroke(255, 255, 0);
    strokeWeight(2);
    rect(errorX, errorY, errorWidth, errorHeight);
    pop();
  } else {
    // Draw directly from sheet - extract full 100x150 box
    
    // Check if knight should be flipped (lag spike backwards running)
    if (knightFlippedBackwards && glitchActive && currentGlitch === 'lagSpike') {
      push();
      translate(knightX + sprite.w * SCALE, drawY); // Translate to flip point
      scale(-1, 1); // Flip horizontally
      image(
        knightSheet,
        0, 0,
        sprite.w * SCALE, sprite.h * SCALE,
        sprite.x, sprite.y,
        sprite.w, sprite.h
      );
      pop();
    } else {
      image(
        knightSheet,
        knightX, drawY,
        sprite.w * SCALE, sprite.h * SCALE,
        sprite.x, sprite.y,
        sprite.w, sprite.h
      );
    }
  }
}

// Applies pixel-level glitch effects to the knight sprite
// Only used for certain glitches that need pixel manipulation
function applyGlitchToKnight(sprite) {
  knightGraphics.loadPixels();
  let pixels = knightGraphics.pixels;
  
if (currentGlitch === 'rgbShift') {
  // RGB channel separation - shifts pixels slightly
  let shift = floor(map(glitchProgress, 0, 1, 0, 20));
  let temp = [...pixels];
  for (let i = 0; i < pixels.length; i += 4) {
    let redIndex = constrain(i - shift * 4, 0, pixels.length - 4);
    let blueIndex = constrain(i + shift * 4, 0, pixels.length - 4);
    pixels[i] = temp[redIndex];
    pixels[i + 2] = temp[blueIndex + 2];
  }
}
  
  else if (currentGlitch === 'lagSpike') {
    // Static noise effect - randomly makes pixels gray
    let noiseAmount = map(glitchProgress, 0.5, 1.0, 0, 0.4);
    for (let i = 0; i < pixels.length; i += 4) {
      if (random() < noiseAmount) {
        let gray = random(255);
        pixels[i] = gray;     // red
        pixels[i + 1] = gray; // green
        pixels[i + 2] = gray; // blue
      }
    }
  }
  
  knightGraphics.updatePixels(); // apply the changes
}

// Draws the monster sprite
// Pretty simple compared to knight drawing
function drawMonster() {
  // All monster sprites in an array
  let spriteArray = [
    monsterSprites.blink1, monsterSprites.blink2, monsterSprites.blink3,
    monsterSprites.blink4, monsterSprites.blink5, monsterSprites.blink6,
    monsterSprites.idle1, monsterSprites.idle2,
    monsterSprites.shock1, monsterSprites.shock2, monsterSprites.shock3
  ];
  
  // Get current sprite (or default to idle1 if something's wrong)
  let sprite = spriteArray[monsterFrame] || monsterSprites.idle1;
  
  // Draw it
  image(
    monsterSheet,
    MONSTER_X, MONSTER_Y,
    sprite.w * SCALE, sprite.h * SCALE,
    sprite.x, sprite.y,
    sprite.w, sprite.h
  );
}

// Full-screen overlay effects for certain glitches
// This draws on top of everything else
function drawOverlayEffects() {
  if (currentGlitch === 'rgbShift') {
    // RGB shift effect - splits color channels and shifts them
    // Also adds psychedelic color cycling
    let shiftAmount = map(glitchProgress, 0, 1, 0, 15);
    
    // Red channel shifted left
    push();
    blendMode(ADD); // additive blending makes colors brighter
    tint(255, 0, 0, 120);
    translate(-shiftAmount, 0);
    image(get(), 0, 0);
    pop();
    
    // Blue channel shifted right
    push();
    blendMode(ADD);
    tint(0, 0, 255, 120);
    translate(shiftAmount, 0);
    image(get(), 0, 0);
    pop();
    
    // Green channel shifted vertically (oscillating)
    push();
    blendMode(ADD);
    tint(0, 255, 0, 100);
    translate(0, sin(glitchProgress * TWO_PI * 3) * shiftAmount);
    image(get(), 0, 0);
    pop();
    
    // Color cycling overlay - goes through full spectrum 10 times
    push();
    blendMode(OVERLAY);
    let hue = (glitchProgress * 360 * 10) % 360;
    colorMode(HSB);
    fill(hue, 90, 100, 40);
    rect(0, 0, width, height);
    colorMode(RGB);
    pop();
  }
  
  if (currentGlitch === 'matrixCode') {
    // Matrix rain effect with density that increases over time
    fill(0, 255, 65, map(glitchProgress, 0, 1, 100, 200));
    textFont('Courier New');
    textSize(20);
    
    // Update and draw each drop
    for (let drop of matrixDrops) {
      text(drop.char, drop.x, drop.y);
      drop.y += drop.speed;
      if (drop.y > height) {
        drop.y = 0;
        drop.x = random(width);
      }
      // Randomly change characters
      if (random() < 0.1) {
        drop.char = random(['0', '1', 'ア', 'イ', 'ウ', 'エ', 'オ']);
      }
    }
    
    // Add extra letters in columns as glitch progresses
    // Creates that dense "stream" effect
    if (glitchProgress > 0.6) {
      let columnDensity = floor(map(glitchProgress, 0.6, 1.0, 1, 8));
      for (let drop of matrixDrops) {
        for (let j = 1; j <= columnDensity; j++) {
          let char = random(['0', '1', 'ア', 'イ', 'ウ', 'エ', 'オ']);
          text(char, drop.x, drop.y - (j * 25));
          text(char, drop.x, drop.y + (j * 25));
        }
      }
    }
  }
  
  // System failure warning at 70% progress
  if (glitchProgress > 0.7) {
    fill(255, 0, 0);
    textSize(40);
    textFont('Courier New');
    textAlign(CENTER);
    text('[SYSTEM FAILURE]', width/2, 100);
  }
  
  // Other glitch effects
  
  if (currentGlitch === 'screenTear') {
    // Screen tearing effect - horizontal strips shifted
    for (let y = 0; y < height; y += 40) {
      let offset = sin((y + glitchProgress * 500) * 0.1) * glitchProgress * 50;
      copy(0, y, width, 20, offset, y, width, 20);
    }
  }
  
  if (currentGlitch === 'invertColors') {
    // Flashing color inversion
    if (floor(glitchProgress * 20) % 2 === 0) {
      filter(INVERT);
    }
  }
  
  if (currentGlitch === 'scanLines') {
    // CRT scanlines - trying to keep the aesthetic world building up
    push();
    stroke(0, map(glitchProgress, 0, 1, 150, 255));
    strokeWeight(3);
    for (let y = 0; y < height; y += 2) {
      line(0, y, width, y);
    }
    // Flickering overlay
    if (floor(glitchProgress * 50) % 2 === 0) {
      fill(0, 80);
      rect(0, 0, width, height);
    }
    pop();
  }
  
  if (currentGlitch === 'chromaticAberration') {
    // Chromatic aberration - color fringing, shiny pokemon vibes
    let offset = map(glitchProgress, 0, 1, 0, 20);
    push();
    blendMode(SCREEN);
    tint(255, 0, 0);
    image(get(), -offset, -offset);
    tint(0, 255, 255);
    image(get(), offset, offset);
    pop();
  }
  
  if (currentGlitch === 'dataMosh') {
    // Data corruption effect, super hard to get right. its also really intensive at higher scaling so i was forced reduce the impact
    loadPixels();
    for (let i = 0; i < pixels.length; i += 80) {
      if (random() < glitchProgress * 0.3) {
        let shift = floor(random(-50, 50)) * 4;
        let newIndex = constrain(i + shift, 0, pixels.length - 4);
        pixels[i] = pixels[newIndex];
        pixels[i + 1] = pixels[newIndex + 1];
        pixels[i + 2] = pixels[newIndex + 2];
      }
    }
    updatePixels();
  }
  
  if (currentGlitch === 'vhsDistortion') {
    // VHS tracking distortion
    push();
    for (let y = 0; y < height; y += 20) {
      let offset = sin(y * 0.1 + glitchProgress * 10) * glitchProgress * 30;
      copy(0, y, width, 20, offset, y, width, 20);
    }
    // Add noise
    loadPixels();
    for (let i = 0; i < pixels.length; i += 80) {
      if (random() < 0.1) {
        pixels[i] = pixels[i + 1] = pixels[i + 2] = random(100, 200);
      }
    }
    updatePixels();
    pop();
  }
  
  if (currentGlitch === 'noiseStorm') {
    // Heavy static noise
    loadPixels();
    let noiseAmount = map(glitchProgress, 0, 1, 0.1, 0.8);
    for (let i = 0; i < pixels.length; i += 40) {
      if (random() < noiseAmount) {
        let val = random(255);
        pixels[i] = val;
        pixels[i + 1] = val;
        pixels[i + 2] = val;
      }
    }
    updatePixels();
  }
  
  if (currentGlitch === 'mirrorWorld') {
    // Single horizontal mirror flip - simple and disorienting
    let canvasCopy = get();
    
    push();
    translate(width / 2, height / 2);
    
    // Just flip once at the start and keep it flipped
    scale(-1, 1);
    
    image(canvasCopy, -width / 2, -height / 2);
    pop();
  }
  
  // NEW GLITCH EFFECTS
  
  if (currentGlitch === 'resolutionCollapse') {
    // Pixelation effect - downsample and upsample the entire canvas
    let pixelationLevel = floor(map(glitchProgress, 0, 1, 1, 20));
    
    if (pixelationLevel > 1) {
      // Capture current canvas
      let temp = get();
      
      // Calculate low-res dimensions
      let lowWidth = floor(width / pixelationLevel);
      let lowHeight = floor(height / pixelationLevel);
      
      push();
      // Disable image smoothing for chunky pixels
      drawingContext.imageSmoothingEnabled = false;
      
      // Draw at low resolution then stretch back to full size
      image(temp, 0, 0, lowWidth, lowHeight); // Draw small version
      image(get(0, 0, lowWidth, lowHeight), 0, 0, width, height); // Stretch to full size
      
      pop();
    }
  }
}
function updateGlitch() {
  // Different progression speeds for different effects, from testing build, just kept tweaking till things felt good.
  let progressSpeed = 0.005; // Base speed
  
  if (currentGlitch === 'rgbShift') {
    progressSpeed = 0.014;
   
    if (!rgbGlitchSoundPlayed && rgbGlitchSound && !isMuted) {
      rgbGlitchSound.setVolume(0.4); 
      rgbGlitchSound.play();
      rgbGlitchSoundPlayed = true;
    }
  } else if (currentGlitch === 'vhsDistortion' || currentGlitch === 'screenTear') {
    progressSpeed = 0.050; 
  } else if (currentGlitch === 'noiseStorm') {
    progressSpeed = 0.020;
  } else if (currentGlitch === 'matrixCode') {
    progressSpeed = 0.0033; 
  } else if (currentGlitch === 'mirrorWorld') {
    progressSpeed = 0.004; 
  } else if (currentGlitch === 'floorCollapse') {
    progressSpeed = 0.005; 
  } else {
    progressSpeed = 0.008;
  }
  
  glitchProgress += progressSpeed;
  
  // DEBUGGING: Logging progress for dataMosh because I couldn't work out why I was suddenly getting massive framerate death. It was the p5js version in my HTML file :) 
if (currentGlitch === 'dataMosh' && frameCount % 60 === 0) {
  console.log('dataMosh progress:', glitchProgress, 'speed:', progressSpeed);
}

  // For pixel explosion, cap progress at 1.0 and wait for pixels to finish bouncing around on the floor before the event ends
  if (currentGlitch === 'pixelExplosion' && glitchProgress >= 1.0) {
    glitchProgress = 1.0;
  }
  
  // Pixel explosion event
  if (currentGlitch === 'pixelExplosion') {
    //just kept tweaking till it was lined up, but also used audacity a fair ammount to kinda manipulate sound files and get them to correct lengths for the events
    if (glitchProgress >= 0.437 && !pixelBurstSoundPlayed && pixelBurstSound && !isMuted) {
      pixelBurstSound.play(); // Play from beginning, because i had it queued for the explosion, but i had a riser in the .wav file, so it needed to play before the explosion
      pixelBurstSoundPlayed = true;
    }
    
    // Lag and struggle, then explode into pixels
    if (glitchProgress < 0.3) {
      glitchStruggleSpeed = 0.6;
      if (floor(glitchProgress * 100) % 4 === 0) screenShakeIntensity = 2;
    } else if (glitchProgress < 0.6) {
      glitchStruggleSpeed = 0.3;
      if (floor(glitchProgress * 100) % 3 === 0) screenShakeIntensity = 4;
    } else if (glitchProgress < 0.8) {
      glitchStruggleSpeed = 0.0;
      screenShakeIntensity = 6;
    } else if (glitchProgress >= 0.8 && !pixelExplosionTriggered) {
      // Trigger explosion ONCE (sound already playing with buildup)
      explodeKnightIntoPixels();
      pixelExplosionTriggered = true;
    }
    
    // Don't reset early - let the end logic handle it with proper pause
  }
  // LAG SPIKE - Rubber banding between random positions
  else if (currentGlitch === 'lagSpike') {
    // Play lag spike sound once
    if (!lagSpikeSoundPlayed && lagSpikeSound && !isMuted) {
      lagSpikeSound.play();
      lagSpikeSoundPlayed = true;
    }
    
    // Rapid rubber banding - teleport every 5 frames
    if (frameCount % 5 === 0) {
      let rubberBandState = floor(random(8));
      
      switch(rubberBandState) {
        case 0: // Back at spawn
          knightX = KNIGHT_START_X;
          knightY = KNIGHT_START_Y;
          knightFlippedBackwards = false;
          break;
        case 1: // Strike position
          knightX = MONSTER_X - 100 * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 2: // Mid run position
          knightX = KNIGHT_START_X + 300 * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 3: // Running BACKWARDS (flipped sprite)
          knightX = KNIGHT_START_X + random(100, 300) * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = true; // Flip sprite!
          break;
        case 4: // On ceiling (upside down Y)
          knightX = KNIGHT_START_X + random(100, 400) * SCALE;
          knightY = -400 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 5: // Way ahead
          knightX = MONSTER_X - 200 * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 6: // Random mid position
          knightX = KNIGHT_START_X + random(50, 500) * SCALE;
          knightY = -20 * SCALE;
          knightFlippedBackwards = false;
          break;
        case 7: // Back to normal running
          // Continue normal movement
          knightFlippedBackwards = false;
          break;
      }
      
      // Heavy shake during rubber banding
      screenShakeIntensity = 8;
    }
    
    // Slow struggle forward between teleports
    glitchStruggleSpeed = 0.4;
  }
  // Floor collapse event handling
  else if (currentGlitch === 'floorCollapse') {
    // Play sound once at the beginning
    if (!floorCollapseSoundPlayed && breakingRocksSound && !isMuted) {
      breakingRocksSound.play();
      floorCollapseSoundPlayed = true;
    }
    
    // Progress through phases with SHUDDERS and PAUSES between cracks
    if (glitchProgress < 0.08) {
      // Shudder before first crack
      floorCollapsePhase = 0;
      crackLevel = 0;
      glitchStruggleSpeed = 0.9;
      if (floor(glitchProgress * 200) % 5 === 0) screenShakeIntensity = 2;
    } else if (glitchProgress < 0.20) {
      // Phase 1: First crack appears, knight struggles
      floorCollapsePhase = 1;
      crackLevel = 1;
      glitchStruggleSpeed = 0.7;
    } else if (glitchProgress < 0.28) {
      // Shudder/pause before second crack
      if (floor(glitchProgress * 200) % 5 === 0) screenShakeIntensity = 3;
    } else if (glitchProgress < 0.42) {
      // Phase 2: Second crack
      floorCollapsePhase = 2;
      crackLevel = 2;
      glitchStruggleSpeed = 0.5;
    } else if (glitchProgress < 0.50) {
      // Shudder/pause before third crack
      if (floor(glitchProgress * 200) % 4 === 0) screenShakeIntensity = 4;
    } else if (glitchProgress < 0.66) {
      // Phase 3: Third crack
      floorCollapsePhase = 3;
      crackLevel = 3;
      glitchStruggleSpeed = 0.3;
    } else if (glitchProgress < 0.74) {
      // Shudder/pause before fourth crack
      if (floor(glitchProgress * 200) % 3 === 0) screenShakeIntensity = 5;
    } else if (glitchProgress < 0.88) {
      // Phase 4: Fourth crack - major damage
      floorCollapsePhase = 4;
      crackLevel = 4;
      glitchStruggleSpeed = 0.1;
    } else {
      // Phase 5: Floor fully broken - knight falls
      floorCollapsePhase = 5;
      glitchStruggleSpeed = 0.0;
      screenShakeIntensity = 6;
      // Knight falls - increase Y gradually
      knightY += 3;
    }
  } else {
    // Original struggle sequence for other glitches
    if (glitchProgress < 0.2) glitchStruggleSpeed = 0.8;
    else if (glitchProgress < 0.4) glitchStruggleSpeed = 0.5;
    else if (glitchProgress < 0.6) glitchStruggleSpeed = 0.3;
    else if (glitchProgress < 0.8) glitchStruggleSpeed = 0.1;
    else glitchStruggleSpeed = 0.0;
    
    // Specific effects for new glitches, added these towards the end, simple glitches after some of the stuff i had already done
    if (currentGlitch === 'timeFreeze' && glitchProgress > 0.5) {
      // Play time freeze sound once
      if (!timeFreezeSoundPlayed && timeFreezeSound && !isMuted) {
        timeFreezeSound.play();
        timeFreezeSoundPlayed = true;
      }
      // Ultra slow motion
      glitchStruggleSpeed = 0.05;
    } else if (currentGlitch === 'noiseStorm') {
      // Loop noise storm sound during entire glitch
      if (!noiseStormSoundPlayed && noiseStormSound && !isMuted) {
        noiseStormSound.loop(); // Loop the sound because i didn't make the sonud file long enough and im lazy
        noiseStormSoundPlayed = true;
      }
    } else if (currentGlitch === 'screenTear') {
      if (!screenTearSoundPlayed && screenTearSound && !isMuted) {
        screenTearSound.play();
        screenTearSoundPlayed = true;
      }
      screenShakeIntensity = floor(glitchProgress * 10);
    } else if (currentGlitch === 'invertColors') {
      if (!invertColoursSoundPlayed && invertColoursSound && !isMuted) {
        invertColoursSound.play();
        invertColoursSoundPlayed = true;
      }
    } else if (currentGlitch === 'scanLines') {
      if (!scanLinesSoundPlayed && scanLinesSound && !isMuted) {
        scanLinesSound.play();
        scanLinesSoundPlayed = true;
      }
    } else if (currentGlitch === 'dataMosh') {
      // Loop data mosh sound during entire glitch
      if (!dataMoshSoundPlayed && dataMoshSound && !isMuted) {
        dataMoshSound.loop(); // Loop instead of play, because i am good at sound design and i dind't mess it up
        dataMoshSoundPlayed = true;
      }
    } else if (currentGlitch === 'gravitySurge') {
      if (!gravitySurgeSoundPlayed && gravitySurgeSound && !isMuted) {
        gravitySurgeSound.play();
        gravitySurgeSoundPlayed = true;
      }
      // Knight bounces up and down
      let bounceAmount = sin(glitchProgress * 20) * 80 * SCALE;
      knightY = -20 * SCALE + bounceAmount;
      if (floor(glitchProgress * 50) % 10 === 0) screenShakeIntensity = 5; //tweaking
    } else if (currentGlitch === 'vhsDistortion') {
      if (!vhsGlitchSoundPlayed && vhsGlitchSound && !isMuted) {
        vhsGlitchSound.setVolume(0.4); //tweaking
        vhsGlitchSound.loop();
        vhsGlitchSoundPlayed = true;
      }
    } else if (currentGlitch === 'resolutionCollapse') {
      if (!resoCollapseSoundPlayed && resoCollapseSound && !isMuted) {
        resoCollapseSound.play();
        resoCollapseSoundPlayed = true;
      }
    } else if (currentGlitch === 'modelNotFound') {
      if (!modelNotFoundSoundPlayed && modelNotFoundSound && !isMuted) {
        modelNotFoundSound.play();
        modelNotFoundSoundPlayed = true;
      }
    } else if (currentGlitch === 'screenTear') {
      screenShakeIntensity = floor(glitchProgress * 10);
    }
  }

  knightVelocity = maxSpeed * glitchStruggleSpeed;
  if (glitchStruggleSpeed > 0) {
    knightX += knightVelocity;
  }
  
  if (glitchProgress >= 1.0) {
    // Stop sounds if they're still playing
    if (currentGlitch === 'invertColors' && invertColoursSound && invertColoursSound.isPlaying()) {
      invertColoursSound.stop();
    }
    if (currentGlitch === 'timeFreeze' && timeFreezeSound && timeFreezeSound.isPlaying()) {
      timeFreezeSound.stop();
    }
    if (currentGlitch === 'noiseStorm' && noiseStormSound && noiseStormSound.isPlaying()) {
      noiseStormSound.stop();
    }
    if (currentGlitch === 'vhsDistortion' && vhsGlitchSound && vhsGlitchSound.isPlaying()) {
      vhsGlitchSound.stop();
    }
    if (currentGlitch === 'dataMosh' && dataMoshSound && dataMoshSound.isPlaying()) {
      dataMoshSound.stop();
    }
    if (currentGlitch === 'modelNotFound' && modelNotFoundSound && modelNotFoundSound.isPlaying()) {
      modelNotFoundSound.stop();
    }
    
    // For pixel explosion, wait for all pixels to settle before resetting
    if (currentGlitch === 'pixelExplosion') {
      if (pixelFragments.length === 0 && glitchProgress >= 1.0) {
        // All pixels finished - reset immediately
        resetLoop();
      }
    } else {
      resetLoop();
    }
  }
}

// Resets everything and starts a new loop
// Called after glitch completes or after leap strike
//very important stuff, its the LOOP!
function resetLoop() {
  loopCount++;
  
  // Remove orange damage flash if it's on. late aesthetic changes
  document.body.classList.remove('strike-intensity');
  
  // Tell the narrative system to advance, go next
  if (typeof updateLoopCounter === 'function') {
    updateLoopCounter(loopCount);
  }
  
  if (typeof advanceNarrative === 'function') {
    advanceNarrative();
  }
  
  // Update LOOP counter display
  const loopElem = document.getElementById('loopCounter');
  if (loopElem) {
    loopElem.textContent = String(loopCount).padStart(3, '0');
  }
  
  // Reset all glitch state
  glitchActive = false;
  currentGlitch = null;
  glitchProgress = 0;
  glitchStruggleSpeed = 1.0;
  floorCollapsePhase = 0;
  crackLevel = 0;
  pixelExplosionTriggered = false;
  pixelExplosionEndTime = null;
  knightFlippedBackwards = false;
  
  // Reset all the sound flags
  // (lots of them because each glitch has its own sound)
  pixelBurstSoundPlayed = false;
  floorCollapseSoundPlayed = false;
  climaxSoundPlayed = false;
  lagSpikeSoundPlayed = false;
  rgbGlitchSoundPlayed = false;
  timeFreezeSoundPlayed = false;
  noiseStormSoundPlayed = false;
  screenTearSoundPlayed = false;
  invertColoursSoundPlayed = false;
  scanLinesSoundPlayed = false;
  dataMoshSoundPlayed = false;
  gravitySurgeSoundPlayed = false;
  vhsGlitchSoundPlayed = false;
  modelNotFoundSoundPlayed = false;
  resoCollapseSoundPlayed = false;
  
  // Stop any glitch sounds that might still be playing, that kept happening nearly broke my ears ngl
  if (invertColoursSound && invertColoursSound.isPlaying()) {
    invertColoursSound.stop();
  }
  if (timeFreezeSound && timeFreezeSound.isPlaying()) {
    timeFreezeSound.stop();
  }
  if (noiseStormSound && noiseStormSound.isPlaying()) {
    noiseStormSound.stop();
  }
  if (vhsGlitchSound && vhsGlitchSound.isPlaying()) {
    vhsGlitchSound.stop();
  }
  if (dataMoshSound && dataMoshSound.isPlaying()) {
    dataMoshSound.stop();
  }
  if (modelNotFoundSound && modelNotFoundSound.isPlaying()) {
    modelNotFoundSound.stop();
  }
  
  
  screenShakeIntensity = 20; //super cool reset animation
  
  // Reset knight position
  knightX = KNIGHT_START_X;
  knightY = KNIGHT_START_Y;
  knightVelocity = 0;
  
  // Reset monster
  monsterShocked = false;
  monsterBlinkTimer = 0;
  
  // Clear effects
  pixelFragments = [];
  radialBurst = null;
  spawnCloud = null;
  
  // Play spawn sound
  // Timing is tricky - sound needs to sync with spawn cloud appearing, but again being able to create the sound files in audacity and get the (ms)
  // 
  // Start at 2.776 seconds into the clip for proper sync
  if (spawnSound && !isMuted) {
    spawnSound.play(0, 1, 0.4, 2.776);
  }
  
  //Ummmmm y'know what I actually don't know
  gameState = 'resetting';
  resetPauseStart = millis();
}

function drawCracks() {
  // Draw progressive cracks based on level. Boom, Boom, Boom. I did actually make a floor break sprite, but i got lazy with syncing it with this. it looks good anyway
  tint(255, 255);
  if (crackLevel >= 1) image(crack1, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  if (crackLevel >= 2) image(crack2, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  if (crackLevel >= 3) image(crack3, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  if (crackLevel >= 4) image(crack4, 0, 0, DISPLAY_WIDTH, DISPLAY_HEIGHT);
  noTint();
  
  // oh yeah here! it doesn't work for some reason, never spent the time to work out why
  if (currentGlitch === 'floorCollapse' && floorCollapsePhase >= 1 && floorCollapsePhase <= 5) {
    let frameIndex = constrain(floorCollapsePhase - 1, 0, 4);
    let frameX = frameIndex * 60;
    let floorX = knightX;
    let floorY = KNIGHT_START_Y + 75 * SCALE;
    image(floorBreakSheet,
      floorX - 30 * SCALE,
      floorY - 30 * SCALE,
      60 * SCALE,
      60 * SCALE,
      frameX, 0, 60, 60
    );
  }
}


function initSpawnCloud() {
  // Smoke sprite: 4 frames in 100x100 boxes on 400x100 canvas
  // Sprites have 5px clearance at bottom
  spawnCloud = {
    frame: 0,
    life: 0,
    x: KNIGHT_START_X + 50 * SCALE, // Center of knight
    y: 25 * SCALE // Position so bottom is 5px above ground and lines up with the bottom of the knight
  };
}

function drawSpawnCloud() {
  if (!spawnCloud) return;
  
  // Animate through 4 frames
  spawnCloud.life++;
  spawnCloud.frame = floor(spawnCloud.life / 10) % 4; // Change frame every 10 updates
  
  // Draw single smoke sprite
  let frameX = spawnCloud.frame * 100;
  let size = 100 * SCALE;
  
  image(smokeSheet, 
    spawnCloud.x - size/2, 
    spawnCloud.y, 
    size, 
    size,
    frameX, 0, 100, 100
  );
}

function explodeKnightIntoPixels() {
  // footsteps already playing with buildup from earlier trigger
  
  // Stop footsteps when explosion happens
  if (knightRunningSound && knightRunningSound.isPlaying()) {
    knightRunningSound.stop();
  }
  
  pixelFragments = [];

  // ended up DOUBLing the explosion pixels - 300 total (was 150)
  let centerX = knightX + 50 * SCALE;
  let centerY = (currentGlitch === 'floorCollapse' && floorCollapsePhase === 5) 
    ? knightY + 40 * SCALE
    : -20 * SCALE + 75 * SCALE;
  
  // Create a denser grid: 20×15 = 300 pixels (was 10×15 = 150)
  for (let y = 0; y < 15; y++) {
    for (let x = 0; x < 20; x++) {
      let colorRow = floor(random(3));
      let sizeCol = floor(random(5));  
      
      pixelFragments.push({
        x: centerX - 50 * SCALE + x * 5 * SCALE,
        y: centerY - 75 * SCALE + y * 10 * SCALE,
        vx: random(-8, 8), // MUCH WIDER spread (was -3, 3)
        vy: random(-10, -0.5), // Higher initial velocity
        gravity: 0.35, // Slightly more gravity
        alpha: 255,
        rotation: random(TWO_PI),
        rotSpeed: random(-0.15, 0.15),
        spriteX: sizeCol * 32,
        spriteY: colorRow * 32,
        size: (sizeCol + 1) * 4 * SCALE,
        bounced: false, 
        onGround: false
      });
    }
  }
}

function drawPixelFragments() {
  const FLOOR_Y = 510; // Knight's feet level (raised from 530)
  
  for (let i = pixelFragments.length - 1; i >= 0; i--) {
    let frag = pixelFragments[i];
    
    // Update physics
    if (!frag.onGround) {
      frag.x += frag.vx;
      frag.y += frag.vy;
      frag.vy += frag.gravity;
      
      // Floor collision with bounce
      if (frag.y >= FLOOR_Y && !frag.bounced) {
        frag.y = FLOOR_Y;
        frag.vy = -frag.vy * 0.4; // Bounce with 40% energy
        frag.vx *= 0.7; // Friction
        frag.bounced = true;
        
        // Settle if bounce is small
        if (abs(frag.vy) < 1) {
          frag.onGround = true;
          frag.vy = 0;
          frag.vx *= 0.9;
        }
      }
    } else {
      // On ground - slow drift
      frag.vx *= 0.95;
      if (abs(frag.vx) < 0.1) frag.vx = 0;
    }
    
    frag.alpha -= 3.5; // Faster fade (was 1.5)
    frag.rotation += frag.rotSpeed * (frag.onGround ? 0.3 : 1);
    
    // Draw pixel block from sprite sheet
    push();
    translate(frag.x, frag.y);
    rotate(frag.rotation);
    tint(255, frag.alpha);
    imageMode(CENTER);
    image(pixelBlockSheet, 
      0, 0,
      frag.size, frag.size,
      frag.spriteX, frag.spriteY, 32, 32
    );
    imageMode(CORNER);
    pop();
    
    // Remove if faded
    if (frag.alpha <= 0) {
      pixelFragments.splice(i, 1);
    }
  }
  noTint();
}

function drawUIElements() {

  if (infinitySprite) {
    image(infinitySprite, 100, 37, 70, 70); 
  }
  if (heartSprite) {
    image(heartSprite, 15, 7, 130, 130); 
  }
}


function triggerRadialBurst() {
  // Center on knight's actual position
  let centerX = knightX + 50 * SCALE;
  let centerY = -20 * SCALE + 75 * SCALE; 
  radialBurst = {
    x: centerX,
    y: centerY,
    frame: 0,
    life: 0
  };
  // Massive screen shake when knight explodes
  screenShakeIntensity = 25;
}

function drawRadialBurst() {
  if (!radialBurst) return;
  
  radialBurst.life++;
  radialBurst.frame = floor(radialBurst.life / 12); // 12 frames per sprite = MUCH slower
  
  if (radialBurst.frame >= 7) {
    radialBurst = null;
    return;
  }
  
  // Radial explosion
  let frameX = radialBurst.frame * 120;
  let size = 120 * SCALE * 2.5;
  
  image(explosionSheet,
    radialBurst.x - size/2,
    radialBurst.y - size/2,
    size, size,
    frameX, 0, 120, 120
  );
}

// Picks and triggers a random glitch effect
// Called when knight gets close to monster or randomly during running
function triggerRandomGlitch() {
  // All 17 glitch types, used to be more in test versions. but i cut it down to save time
  let glitches = [
    'lagSpike', 
    'matrixCode', 
    'rgbShift', 
    'floorCollapse', 
    'pixelExplosion',
    'screenTear',
    'timeFreeze',
    'gravitySurge',
    'invertColors',
    'scanLines',
    'chromaticAberration',
    'dataMosh',
    'vhsDistortion',
    'noiseStorm',
    'mirrorWorld',
    'modelNotFound',
    'resolutionCollapse'
  ];
  
  currentGlitch = random(glitches);
  glitchActive = true;
  glitchProgress = 0;
  gameState = 'glitching';
  
  // Reset various flags
  floorCollapsePhase = 0;
  crackLevel = 0;
  pixelExplosionTriggered = false;
  
  // Reset all sound flags so sounds only play once per glitch
  pixelBurstSoundPlayed = false;
  floorCollapseSoundPlayed = false;
  lagSpikeSoundPlayed = false;
  rgbGlitchSoundPlayed = false;
  timeFreezeSoundPlayed = false;
  noiseStormSoundPlayed = false;
  screenTearSoundPlayed = false;
  invertColoursSoundPlayed = false;
  scanLinesSoundPlayed = false;
  dataMoshSoundPlayed = false;
  gravitySurgeSoundPlayed = false;
  vhsGlitchSoundPlayed = false;
  modelNotFoundSoundPlayed = false;
  resoCollapseSoundPlayed = false;
  
  // Matrix code needs special setup
  if (currentGlitch === 'matrixCode') {
    initMatrixDrops();
    // Play matrix sound
    if (matrixSound && !isMuted) {
      matrixSound.play();
    }
  }
}

// Initialize matrix drops for the matrix code effect
function initMatrixDrops() {
  matrixDrops = [];
  for (let i = 0; i < 150; i++) {
    matrixDrops.push({
      x: random(width),
      y: random(-height, 0), // start above screen
      speed: random(3, 10),
      char: random(['0', '1', 'ア', 'イ', 'ウ']) // binary or japanese characters
    });
  }
  }
  
function updateUI() {
  // Only update if elements exist (for development version)
  const stateElem = document.getElementById('stateDisplay');
  if (stateElem) {
    stateElem.textContent = gameState.toUpperCase();
  }
  
  const distElem = document.getElementById('distanceDisplay');
  if (distElem) {
    distElem.textContent = floor((knightX - KNIGHT_START_X) / SCALE) + 'px';
  }
}

function updateRunningSound() {
  // List of glitches where knight should still have footsteps
  let continuousFootstepGlitches = [
    'floorCollapse', 
    'timeFreeze',
    'invertColors',
    'scanLines',
    'chromaticAberration',
    'mirrorWorld',
    'resolutionCollapse',
    'matrixCode'
  ];
  
  // Play running sound when accelerating, running, approaching strike, or during specific glitches
  let isRunningState = (gameState === 'accelerating' || gameState === 'running' || gameState === 'approachingStrike');
  let isGlitchingWithFootsteps = (gameState === 'glitching' && continuousFootstepGlitches.includes(currentGlitch));
  let shouldPlayRunning = (isRunningState || isGlitchingWithFootsteps) && !isMuted;
  
  if (shouldPlayRunning) {
    if (knightRunningSound && !knightRunningSound.isPlaying()) {
      knightRunningSound.loop()
        }
    
    // Fade volume during matrix code as background fades (was simpler than reverb)
    if (currentGlitch === 'matrixCode' && knightRunningSound) {
      // Reduce volume as glitch progresses to create distant/fading effect
      let volumeFade = map(glitchProgress, 0, 1, 0.5, 0.15); 
      knightRunningSound.setVolume(volumeFade);
    } else if (knightRunningSound) {
      // Normal volume for other states (reduced from 1.0 to 0.5)
      knightRunningSound.setVolume(0.5);
    }
  } else {
    if (knightRunningSound && knightRunningSound.isPlaying()) {
      knightRunningSound.stop();
    }
  }
}

// Easing functions for smooth movement
// Found these formulas online - they make movement look way more natural
// than linear acceleration

function easeInOutQuad(t) {
  // Starts slow, speeds up in middle, slows at end
  return t < 0.5 ? 2 * t * t : 1 - pow(-2 * t + 2, 2) / 2;
}

function easeOutQuad(t) {
  // Starts fast, slows down at the end
  // This is what I use for the knight's acceleration
  return 1 - (1 - t) * (1 - t);
}

// Control functions
function restartSequence() {
  resetLoop();
  loopCount--;
  document.getElementById('loopCounter').textContent = String(loopCount).padStart(3, '0');
}

/*

These were used during development for testing individual glitches and effects.
Keeping them here in case I need to debug something later but they're not
used in the actual exhibition version.


function triggerFullEvent(glitchType) {
  // Reset and start from beginning
  restartSequence();
  // Skip spawn if enabled
  if (showSpawnCloud) {
    setTimeout(() => {
      gameState = 'idle1';
      stateStartTime = millis();
    }, SPAWN_CLOUD_DURATION);
  }
  // After idle, jump to running
  setTimeout(() => {
    gameState = 'running';
    knightVelocity = maxSpeed;
    knightX = KNIGHT_START_X + 50 * SCALE;
    stateStartTime = millis();
    // Trigger glitch after brief run
    setTimeout(() => {
      currentGlitch = glitchType;
      glitchActive = true;
      glitchProgress = 0;
      gameState = 'glitching';
      floorCollapsePhase = 0;
      crackLevel = 0;
      floorCollapseSoundPlayed = false;
      
      if (glitchType === 'matrixCode') {
        initMatrixDrops();
        if (matrixSound && !isMuted) {
          matrixSound.play();
        }
      }
      
      if (glitchType === 'floorCollapse') {
        if (breakingRocksSound && !isMuted) {
          breakingRocksSound.play();
        }
        floorCollapseSoundPlayed = true;
      }
    }, 500);
  }, showSpawnCloud ? SPAWN_CLOUD_DURATION + 1000 : 1000);
}

function testPixelExplosion() {
  explodeKnightIntoPixels();
}

function testRadialBurst() {
  triggerRadialBurst();
}

function updateStrikeDist(value) {
  strikeDistance = parseInt(value);
  document.getElementById('strikeDistValue').textContent = strikeDistance;
}

function updateStrikeShake(value) {
  strikeShakeIntensity = parseInt(value);
  document.getElementById('strikeShakeValue').textContent = strikeShakeIntensity;
}

function toggleSpawnCloud(checked) {
  showSpawnCloud = checked;
}

function togglePixelExplosion(checked) {
  showPixelExplosion = checked;
}

function toggleRadialBurst(checked) {
  showRadialBurst = checked;
  if (checked) {
    showPixelExplosion = false;
    document.getElementById('pixelExplosionCheck').checked = false;
  }
}

function toggleMute() {
  isMuted = !isMuted;
  
  if (isMuted) {
    if (musicTrack) musicTrack.setVolume(0);
    if (ambienceTrack) ambienceTrack.setVolume(0);
    if (knightRunningSound && knightRunningSound.isPlaying()) knightRunningSound.stop();
    document.getElementById('muteButton').innerHTML = '🔇 SOUND OFF';
    document.getElementById('muteButton').style.background = '#ff4444';
    document.getElementById('muteButton').style.color = '#fff';
  } else {
    if (musicTrack) musicTrack.setVolume(0.7);
    if (ambienceTrack) ambienceTrack.setVolume(0.2);
    document.getElementById('muteButton').innerHTML = '🔊 SOUND ON';
    document.getElementById('muteButton').style.background = '#00ff00';
    document.getElementById('muteButton').style.color = '#000';
  }
}

function toggleCracks(checked) {
  showCracks = checked;
}

function triggerGlitch(type) {
  if (gameState === 'running' || gameState === 'accelerating' || gameState === 'strikePause' || gameState === 'approachingStrike') {
    currentGlitch = type;
    glitchActive = true;
    glitchProgress = 0;
    gameState = 'glitching';
    pixelExplosionTriggered = false;
    
    if (type === 'matrixCode') {
      initMatrixDrops();
    }
  }
}


*/

// Keep mousePressed for audio initialization (browser requirement)
function mousePressed() {
  // Ensure audio starts on first click (browser requirement)
  if (!soundsLoaded && musicTrack && ambienceTrack && !musicTrack.isPlaying()) {
    userStartAudio();
    musicTrack.loop();
    musicTrack.setVolume(isMuted ? 0 : 0.7);
    ambienceTrack.loop();
    ambienceTrack.setVolume(isMuted ? 0 : 0.2);
    soundsLoaded = true;
    console.log('Audio started on click');
  }
}